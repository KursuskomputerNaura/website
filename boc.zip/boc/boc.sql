-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 21, 2016 at 03:59 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `boc`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
  `id_artikel` int(11) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(11) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text,
  `gambar` varchar(50) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_artikel`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `id_kategori`, `judul`, `isi`, `gambar`, `tanggal`, `id_user`) VALUES
(1, 1, 'IMI AWARDS 2016 BERLANGSUNG DENGAN SEMARAK', '<div><div><p>SUBANG, 14 Desember 2016 â€“ Ikatan Motor Indonesia (IMI) sukses menggelar malam penghargaan IMI Awards 2016 yang diadakan di Sari Ater Hotel &amp; Resort, Subang, Jawa Barat pada Selasa (13/12) kemarin. Acara ini berlangsung semarak dengan dihadiri oleh atlet-atlet otomotif berprestasiâ€”mulai dari roda dua hingga roda empatâ€”yang datang dari berbagai daerah di Tanah Air.</p><p>Momen ini tentunya menjadi kebahagiaan tersendiri bagi mereka yang memiliki prestasi gemilang di sepanjang tahun 2016. Beberapa contoh atlet berkualitas yang diberikan penghargaan oleh IMI di antaranya Rio Haryanto, Sean Gelael, Presley Martono, Demas Agil, Ryan Nirwan, Keanon Santoso, Gerry Salim, Andy Gilang, hingga Mario Salontahe.<br>&nbsp;<br>Masing-masing dari mereka sukses di cabang olahraga otomotif yang digeluti, seperti misalnya Demas yang keluar sebagai Juara Umum ajang Indonesia Night City Slalom 2016. Lain halnya dengan Mario yang keluar sebagai juara Umum Kejurnas Grasstrack 2016. Sedangkan Rio berhasil meraih penghargaan berkat usaha dan kerja kerasnya yang membuatnya bisa menjadi pebalap Tanah Air pertama yang terjun di salah satu ajang olahraga otomotif paling bergengsi di dunia, F1.  <br></p><p>Selain menyerahkan penghargaan bagi para atlet yang berprestasi, IMI juga turut memberikan apresiasi terhadap tubuh internal IMI, secara khusus bagi Pengprov IMI yang memiliki kinerja terbaik di sepanjang tahun 2016. Penghargaan ini sendiri pada akhirnya berhasil diraih oleh Pengprov IMI Jawa Timur.<br>&nbsp;<br>Berbicara mengenai proses pemilihan Pengprov IMI terbaik, Ketua Umum IMI Pusat, Sadikin Aksa, mengatakan, â€œProses pemilihan ini kami tinjau dari berbagai aspek penting, seperti misalnya apa yang Pengprov tersebut lakukan demi kemajuan olahraga otomotif di daerahnya, lalu seberapa aktif Pengprov dan anggota-anggota klub penyelenggara dalam mengadakan kegiatan otomotif sekaligus kegiatan wisata, dan lain sebagainya.â€<br>&nbsp;<br>IMI Awards 2016 terasa lebih lengkap karena IMI juga memberikan apresiasi kepada pihak-pihak berpengaruh lain dalam kategori lifetime achievement. Beberapa yang mendapatkan penghargaan ini, yaitu mantan Ketua Umum PP IMI, Nanan Sokearna, anggota kehormatan olahraga sepeda motor IMI, Bambang Gunardi, pencipta himne dan mars IMI, Moordiana, hingga pengaransemen himne dan mars IMI, Purwa Tjaraka.  <br></p>  </div>  </div>', 'ddd.jpg', '2016-12-19', 1),
(2, 1, 'RAKERNAS 2016 DIHARAPKAN DAPAT MENJADI AMANAH BAGI KEMAJUAN IKATAN MOTOR INDONESIA', '<p>SUBANG, 16 Desember 2016 â€“ Ikatan Motor Indonesia (IMI) sebagai induk organisasi olahraga otomotif di Tanah Air telah sukses menggelar Rapat Kerja Nasional (Rakernas) 2016 yang dilangsungkan di Sari Ater Hotel &amp; Resort, Subang, Jawa Barat pada Kamis (15/12) kemarin.<br>&nbsp;<br>Rakernas tahun ini diharapkan dapat menjadi amanah yang dapat terus dipegang teguh, baik oleh IMI Pusat maupun IMI Provinsi demi kemajuan IMI di masa yang akan datang. Hal ini disampaikan langsung oleh Sekretaris Jenderal IMI Pusat, Jeffrey JP, dalam konferensi pers usai Rakernas. Ia mengatakan, â€œSebelumnya saya mengucapkan terima kasih karena Rakernas IMI di tahun ini dapat berjalan dengan lancar. IMI berharap agar hasil yang telah dibicarakan secara bersama-sama dapat menjadi amanah bagi IMI sendiri demi mewujudkan IMI yang jelas, tegas, serta berwibawa.â€</p><p>Secara khusus, dalam kesempatan yang sama, Jeffrey juga meminta rekan-rekan media untuk terus membantu IMI lewat program media networking yang akan dikembangkan IMI di tahun 2017 mendatang. Selain itu, Jeffrey juga mengungkapkan rencana IMI untuk menyusun tim yang secara khusus bergerak dalam menentukan program kerja IMI agar menjadi lebih terstruktur.<br>&nbsp;<br>Konferensi pers juga dihadiri oleh Kabid Olahraga Roda Empat IMI Pusat, Poedio Oetojo, Kabid Olahraga Roda Dua IMI Pusat, Medya Saputra, Ketua IMI Provinsi Jawa Barat, Rio Teguh Pribadi, Ketua Bidang Organisasi, H Sutarto, serta Komisi Pembinaan dan Pengembangan, Donni B. Prihandana.<br>&nbsp;<br>Rio sendiri turut angkat bicara dan mengucapkan terima kasih kepada seluruh pihak yang telah mendukung Jawa Barat sebagai tuan rumah Rakernas IMI 2016. â€œTerima kasih untuk kepercayaannya terhadap Jawa Barat sehingga boleh menjadi tuan rumah Rakernas IMI 2016. Salah satu alasan mengapa Jawa Barat dijadikan tuan rumah adalah karena kondisi alam dan letak geografisnya yang mendukung,â€ tutur Rio.<br>&nbsp;<br>Ia menambahkan, â€œSaya juga berharap agar ke depannya, intensitas dalam menggelar Kejurnas di Jawa Barat semakin banyak, baik itu olahraga roda dua maupun roda empat.â€<br>&nbsp;<br>Poedio dan Medya juga sedikit membahas mengenai kalender Kejurnas 2017 yang sudah hampir rampung dirumuskan dan siap disebarluaskan dalam beberapa minggu ke depan. Sementara itu, Jeffrey juga membeberkan bahwa Rakernas 2017 mendatang akan diselenggarakan di Palembang, Sumatera Selatan. Salah satu alasannya adalah agar IMI juga dapat sekaligus memantau perkembangan Sirkuit Jakabaring yang rencananya akan digunakan dalam perhelatan MotoGP tahun 2018.  <br></p>', '2.jpg', '2016-12-19', 1),
(5, 1, 'BANTEN AUTOSHOW 2016', '<p>TANGERANG, &nbsp;Kemeriahan kontes modifikasi Banten Auto Show pada hari kedua 30 Maret 2016&nbsp;jauh lebih meriah dari hari sebelumnya, antusias penggila modifikasi Kota Tangerang dan dan sekitarnya dalam menyambut event ini begitu besar hal ini terlihat dari padatnya pengunjung dan jumlah penjualan tiket.</p><p>Meski baru pertama kali digelar, pergelaran Banten Auto Show mampu menyerap perhatian para modifikator, tak heran jika kontes yang digelar di Mall @Alam Sutera ini diikuti oleh jagoan-jagoan modif yang handal, dan persaingan nilai antar peserta sangat ketat.</p><p>â€œPersaingan nilai antar peserta sangat ketat, kami harus meneliti dengan baik bangunan modifikasinya, dan untuk menetapkan juara pada setiap kategori harus benar-benar matang, dan beralasan, karena hal itu penjurian dilakukan selama dua hari dan bahkan sampai larut,â€ ujar Okky Merianto salah satu juri modifikasi Banten Auto Show.</p><p>Event pada hari kedua juga diramaikan dengan kontes audio Fun SPL,tercatat 21 peserta dari empat kelas yang dipertandingkan mengikuti kontes adu kekuatan nilai dB tersebut, selain itu berbagai hiburan seperti dancer, games, band, dan DJ Perform juga turut meramaikan Banten Auto Show.</p><p>Mobil Suzuki Katana garapan Akasia Motor berhasil keluar sebagai King of Banten Auto Show, hal ini karena menurut juri mobil berpenampilan ekstreme tersebut telah dimodifikasi pada seluruh sektor dengan sempurna sesuai regulasi yang telah ditetapkan dewan juri.</p><p>â€œUntuk kedepannya Banten Auto Show akan rutin diadakan setiap tahun, dari gelaran perdana ini kami dapat menyimpulkan bahwa dunia otomotif khususnya modifikasi di Tangerang memang masih mendapat pasar tersendiri,â€ ungkap Ketua Umum BOC selaku penyelenggara event, Edward.&nbsp;</p>', '521726_625241520836425_1642929404_n.jpg', '2016-12-19', 1),
(4, 1, 'HASIL KEJUARAAN GRASSTRACK DAN MINTRAIL BANTEN CUP OPEN 2016', '<p>Walaupun&nbsp;hujan turun di sirkuit Jambu Cisereh, Tigaraksa, Kab. Tangerang, kejuaraan Grasstrack dan Minitrail Banten Open 2016 yang diselenggarakan 30 Oktober kemarin&nbsp;tetap berjalan ketat. Para crosser yang datang berlomba mengikuti 15 kelas yang diperlombakan tetap tampil ngotot. Makanya, persaingan antar pembala di setiap kelas berjalan seru.&nbsp;</p><p>Untuk yang penasaran dengan hasil lomba Kejuaraan Grasstrack dan Minitrail Banten Cup Open 2016, berikut rinciannya:</p><p>Bebek Standar 116 cc Tangerang</p><p>1. (142) Arie CR. &nbsp; &nbsp; Tangerang. &nbsp; &nbsp; YMH</p><p>2. (11) Reza Fahlevi. &nbsp; Curug. &nbsp; &nbsp; &nbsp;YMH</p><p>3. (117) Fecun Costa. &nbsp; &nbsp; &nbsp;TNG. &nbsp; &nbsp; &nbsp;YMH</p><p>&nbsp;</p><p>FFA 250 cc - Tangerang</p><p>1. (150) Cece Hots. &nbsp; &nbsp; &nbsp; TNG. &nbsp; &nbsp; &nbsp; YMH</p><p>2. (175) Roni. &nbsp; &nbsp; &nbsp; &nbsp;Balaraja. &nbsp; &nbsp; &nbsp;YMH</p><p>3. (91) Denis D.R. &nbsp; Balaraja. &nbsp; &nbsp; &nbsp;KWSKI</p><p>&nbsp;</p><p>Minitrail U-12 - Open</p><p>1. (190) Vhery A. &nbsp; &nbsp; &nbsp;Pakem. &nbsp; &nbsp; &nbsp;-</p><p>2. (64) Yurico. &nbsp; &nbsp; &nbsp; &nbsp;Tangsel. &nbsp; &nbsp;-</p><p>3. (48) Dika. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;TNG. &nbsp; &nbsp; &nbsp; &nbsp;-</p><p>&nbsp;</p><p>FFA 250 - Open</p><p>1. (225) Diki Aja. &nbsp; &nbsp; &nbsp; &nbsp;KWSKI. &nbsp; &nbsp; &nbsp; Bekasi</p><p>2. (19) Deden H.D. &nbsp; &nbsp; &nbsp; KWSKI. &nbsp; &nbsp; &nbsp;TNG</p><p>3. (83) Chan Endri. &nbsp; &nbsp; &nbsp;KWSKI. &nbsp; &nbsp; TNG</p><p>&nbsp;</p><p>Enduro Build Up Hobby</p><p>1. (69) Dodi. &nbsp; &nbsp; &nbsp; TNG. &nbsp; &nbsp; &nbsp; KTM</p><p>2. (08) H. Idris. &nbsp; TNG. &nbsp; &nbsp; &nbsp;KTM</p><p>3. (11) Adink. &nbsp; &nbsp; &nbsp;TNG. &nbsp; &nbsp; &nbsp; KTM</p>', 'aa.jpg', '2016-12-19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id_event` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) DEFAULT NULL,
  `isi` text,
  `gambar` varchar(50) DEFAULT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_event`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id_event`, `judul`, `isi`, `gambar`, `id_user`) VALUES
(1, 'Banten Rally Wisata', '', '11.PNG', 0);

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `id_faq` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pesan` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `balas` text NOT NULL,
  PRIMARY KEY (`id_faq`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id_faq`, `nama_lengkap`, `email`, `pesan`, `username`, `balas`) VALUES
(4, 'polan', 'polan@yahoo.com', 'apa kabar?', 'admin', 'baik,anda?');

-- --------------------------------------------------------

--
-- Table structure for table `halaman`
--

CREATE TABLE IF NOT EXISTS `halaman` (
  `id_halaman` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text,
  `gambar` varchar(50) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_halaman`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `halaman`
--

INSERT INTO `halaman` (`id_halaman`, `judul`, `isi`, `gambar`, `id_user`) VALUES
(1, 'SELAMAT DATANG DI WEBSTIE BALARAJA OTOMOTIF SPORTCLUB', '<br><div class="box_banner-3"></div>', 'Jadwal Kejurnas Grasstrack 2016 Agenda Terbaru.jpg', 1),
(2, 'Tentang Kami', 'Salam Olah raga,Balaraja Otomotif Sport Club (BOC) adalah sebuah penyelenggara event dengan tema otomotif , bermula pada tahun 1999 diselenggarakannya kejuaraan Motocross &amp; Grasstrack didaerah Kabupaten Tangerang dengan suksesnya kegiatan tersebut kami terus membuat event untuk para pecinta otomotif dan mencari bakat dalam bidang olahraga Motocross &amp; Grasstrack, dari kejuaran tingkat pemula, sampai tingkat kejuaraan Nasional, event ini diselenggarakan dari tahun 1999 sampai 2010.&amp;Seiring berjalannya event Motocross &amp; Grasstrack, dan pada tahun 2004 kita membuat event Rally Wisata memperingati HUT Kabupaten Tangerang dan diikuti oleh 285 peserta.Pada Tahun 2013 â€œBanten Auto Showâ€ di Alam Sutera Serpong Tangerang Selatan untuk pertama kalinya event Kontes Mobil terbesar di Tangerang dengan jumlah peserta mencapai 150 orang dan di ikuti dari daerah Jabodetabek dan dari luar kota lainnya seperti Bandung.Dari sekian event yang terselenggara dan kami selalu bekerjasama dengan Ikatan Motor Indonesia Banten (IMI) dan instansi lainnya.', 'logo.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(50) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kategori`) VALUES
(1, 'Balap Motor'),
(2, 'Balap Mobil');

-- --------------------------------------------------------

--
-- Table structure for table `kontak`
--

CREATE TABLE IF NOT EXISTS `kontak` (
  `id_kontak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `pesan` text NOT NULL,
  PRIMARY KEY (`id_kontak`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `kontak`
--


-- --------------------------------------------------------

--
-- Table structure for table `menuadmin`
--

CREATE TABLE IF NOT EXISTS `menuadmin` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `icon` varchar(30) NOT NULL,
  `menu_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `menuadmin`
--

INSERT INTO `menuadmin` (`id`, `parent_id`, `title`, `url`, `icon`, `menu_order`) VALUES
(1, 0, 'Dashboard', 'admin.php', 'mws-i-24 i-home', 1),
(2, 0, 'Artikel', '?page=artikel', 'mws-i-24 i-home', 2),
(4, 0, 'User', '?page=user', 'mws-i-24 i-home', 4),
(5, 0, 'Menu', '?page=menu', 'mws-i-24 i-home', 5),
(13, 0, 'Event', '?page=event', '', 5),
(12, 0, 'Keluar', 'logout.php', '', 10),
(11, 0, 'Kategori', '?page=kategori', '', 2),
(14, 0, 'Halaman', '?page=halaman', '', 3),
(16, 0, 'Faq', '?page=faq', '', 9);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_lengkap`, `username`, `password`, `email`) VALUES
(1, '', '', 'd41d8cd98f00b204e9800998ecf8427e', 'polan@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `view_artikel`
--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `boc`.`view_artikel` AS select `boc`.`artikel`.`id_artikel` AS `id_artikel`,`boc`.`artikel`.`id_kategori` AS `id_kategori`,`boc`.`artikel`.`judul` AS `judul`,`boc`.`artikel`.`isi` AS `isi`,`boc`.`artikel`.`gambar` AS `gambar`,`boc`.`artikel`.`tanggal` AS `tanggal`,`boc`.`artikel`.`id_user` AS `id_user`,`boc`.`kategori`.`kategori` AS `kategori`,`boc`.`user`.`username` AS `username` from ((`boc`.`artikel` join `boc`.`user` on((`boc`.`user`.`id_user` = `boc`.`artikel`.`id_user`))) join `boc`.`kategori` on((`boc`.`kategori`.`id_kategori` = `boc`.`artikel`.`id_kategori`)));

--
-- Dumping data for table `view_artikel`
--

INSERT INTO `view_artikel` (`id_artikel`, `id_kategori`, `judul`, `isi`, `gambar`, `tanggal`, `id_user`, `kategori`, `username`) VALUES
(1, 1, 'IMI AWARDS 2016 BERLANGSUNG DENGAN SEMARAK', '<div><div><p>SUBANG, 14 Desember 2016 â€“ Ikatan Motor Indonesia (IMI) sukses menggelar malam penghargaan IMI Awards 2016 yang diadakan di Sari Ater Hotel &amp; Resort, Subang, Jawa Barat pada Selasa (13/12) kemarin. Acara ini berlangsung semarak dengan dihadiri oleh atlet-atlet otomotif berprestasiâ€”mulai dari roda dua hingga roda empatâ€”yang datang dari berbagai daerah di Tanah Air.</p><p>Momen ini tentunya menjadi kebahagiaan tersendiri bagi mereka yang memiliki prestasi gemilang di sepanjang tahun 2016. Beberapa contoh atlet berkualitas yang diberikan penghargaan oleh IMI di antaranya Rio Haryanto, Sean Gelael, Presley Martono, Demas Agil, Ryan Nirwan, Keanon Santoso, Gerry Salim, Andy Gilang, hingga Mario Salontahe.<br>&nbsp;<br>Masing-masing dari mereka sukses di cabang olahraga otomotif yang digeluti, seperti misalnya Demas yang keluar sebagai Juara Umum ajang Indonesia Night City Slalom 2016. Lain halnya dengan Mario yang keluar sebagai juara Umum Kejurnas Grasstrack 2016. Sedangkan Rio berhasil meraih penghargaan berkat usaha dan kerja kerasnya yang membuatnya bisa menjadi pebalap Tanah Air pertama yang terjun di salah satu ajang olahraga otomotif paling bergengsi di dunia, F1.  <br></p><p>Selain menyerahkan penghargaan bagi para atlet yang berprestasi, IMI juga turut memberikan apresiasi terhadap tubuh internal IMI, secara khusus bagi Pengprov IMI yang memiliki kinerja terbaik di sepanjang tahun 2016. Penghargaan ini sendiri pada akhirnya berhasil diraih oleh Pengprov IMI Jawa Timur.<br>&nbsp;<br>Berbicara mengenai proses pemilihan Pengprov IMI terbaik, Ketua Umum IMI Pusat, Sadikin Aksa, mengatakan, â€œProses pemilihan ini kami tinjau dari berbagai aspek penting, seperti misalnya apa yang Pengprov tersebut lakukan demi kemajuan olahraga otomotif di daerahnya, lalu seberapa aktif Pengprov dan anggota-anggota klub penyelenggara dalam mengadakan kegiatan otomotif sekaligus kegiatan wisata, dan lain sebagainya.â€<br>&nbsp;<br>IMI Awards 2016 terasa lebih lengkap karena IMI juga memberikan apresiasi kepada pihak-pihak berpengaruh lain dalam kategori lifetime achievement. Beberapa yang mendapatkan penghargaan ini, yaitu mantan Ketua Umum PP IMI, Nanan Sokearna, anggota kehormatan olahraga sepeda motor IMI, Bambang Gunardi, pencipta himne dan mars IMI, Moordiana, hingga pengaransemen himne dan mars IMI, Purwa Tjaraka.  <br></p>  </div>  </div>', 'ddd.jpg', '2016-12-19', 1, 'Balap Motor', ''),
(2, 1, 'RAKERNAS 2016 DIHARAPKAN DAPAT MENJADI AMANAH BAGI KEMAJUAN IKATAN MOTOR INDONESIA', '<p>SUBANG, 16 Desember 2016 â€“ Ikatan Motor Indonesia (IMI) sebagai induk organisasi olahraga otomotif di Tanah Air telah sukses menggelar Rapat Kerja Nasional (Rakernas) 2016 yang dilangsungkan di Sari Ater Hotel &amp; Resort, Subang, Jawa Barat pada Kamis (15/12) kemarin.<br>&nbsp;<br>Rakernas tahun ini diharapkan dapat menjadi amanah yang dapat terus dipegang teguh, baik oleh IMI Pusat maupun IMI Provinsi demi kemajuan IMI di masa yang akan datang. Hal ini disampaikan langsung oleh Sekretaris Jenderal IMI Pusat, Jeffrey JP, dalam konferensi pers usai Rakernas. Ia mengatakan, â€œSebelumnya saya mengucapkan terima kasih karena Rakernas IMI di tahun ini dapat berjalan dengan lancar. IMI berharap agar hasil yang telah dibicarakan secara bersama-sama dapat menjadi amanah bagi IMI sendiri demi mewujudkan IMI yang jelas, tegas, serta berwibawa.â€</p><p>Secara khusus, dalam kesempatan yang sama, Jeffrey juga meminta rekan-rekan media untuk terus membantu IMI lewat program media networking yang akan dikembangkan IMI di tahun 2017 mendatang. Selain itu, Jeffrey juga mengungkapkan rencana IMI untuk menyusun tim yang secara khusus bergerak dalam menentukan program kerja IMI agar menjadi lebih terstruktur.<br>&nbsp;<br>Konferensi pers juga dihadiri oleh Kabid Olahraga Roda Empat IMI Pusat, Poedio Oetojo, Kabid Olahraga Roda Dua IMI Pusat, Medya Saputra, Ketua IMI Provinsi Jawa Barat, Rio Teguh Pribadi, Ketua Bidang Organisasi, H Sutarto, serta Komisi Pembinaan dan Pengembangan, Donni B. Prihandana.<br>&nbsp;<br>Rio sendiri turut angkat bicara dan mengucapkan terima kasih kepada seluruh pihak yang telah mendukung Jawa Barat sebagai tuan rumah Rakernas IMI 2016. â€œTerima kasih untuk kepercayaannya terhadap Jawa Barat sehingga boleh menjadi tuan rumah Rakernas IMI 2016. Salah satu alasan mengapa Jawa Barat dijadikan tuan rumah adalah karena kondisi alam dan letak geografisnya yang mendukung,â€ tutur Rio.<br>&nbsp;<br>Ia menambahkan, â€œSaya juga berharap agar ke depannya, intensitas dalam menggelar Kejurnas di Jawa Barat semakin banyak, baik itu olahraga roda dua maupun roda empat.â€<br>&nbsp;<br>Poedio dan Medya juga sedikit membahas mengenai kalender Kejurnas 2017 yang sudah hampir rampung dirumuskan dan siap disebarluaskan dalam beberapa minggu ke depan. Sementara itu, Jeffrey juga membeberkan bahwa Rakernas 2017 mendatang akan diselenggarakan di Palembang, Sumatera Selatan. Salah satu alasannya adalah agar IMI juga dapat sekaligus memantau perkembangan Sirkuit Jakabaring yang rencananya akan digunakan dalam perhelatan MotoGP tahun 2018.  <br></p>', '2.jpg', '2016-12-19', 1, 'Balap Motor', ''),
(5, 1, 'BANTEN AUTOSHOW 2016', '<p>TANGERANG, &nbsp;Kemeriahan kontes modifikasi Banten Auto Show pada hari kedua 30 Maret 2016&nbsp;jauh lebih meriah dari hari sebelumnya, antusias penggila modifikasi Kota Tangerang dan dan sekitarnya dalam menyambut event ini begitu besar hal ini terlihat dari padatnya pengunjung dan jumlah penjualan tiket.</p><p>Meski baru pertama kali digelar, pergelaran Banten Auto Show mampu menyerap perhatian para modifikator, tak heran jika kontes yang digelar di Mall @Alam Sutera ini diikuti oleh jagoan-jagoan modif yang handal, dan persaingan nilai antar peserta sangat ketat.</p><p>â€œPersaingan nilai antar peserta sangat ketat, kami harus meneliti dengan baik bangunan modifikasinya, dan untuk menetapkan juara pada setiap kategori harus benar-benar matang, dan beralasan, karena hal itu penjurian dilakukan selama dua hari dan bahkan sampai larut,â€ ujar Okky Merianto salah satu juri modifikasi Banten Auto Show.</p><p>Event pada hari kedua juga diramaikan dengan kontes audio Fun SPL,tercatat 21 peserta dari empat kelas yang dipertandingkan mengikuti kontes adu kekuatan nilai dB tersebut, selain itu berbagai hiburan seperti dancer, games, band, dan DJ Perform juga turut meramaikan Banten Auto Show.</p><p>Mobil Suzuki Katana garapan Akasia Motor berhasil keluar sebagai King of Banten Auto Show, hal ini karena menurut juri mobil berpenampilan ekstreme tersebut telah dimodifikasi pada seluruh sektor dengan sempurna sesuai regulasi yang telah ditetapkan dewan juri.</p><p>â€œUntuk kedepannya Banten Auto Show akan rutin diadakan setiap tahun, dari gelaran perdana ini kami dapat menyimpulkan bahwa dunia otomotif khususnya modifikasi di Tangerang memang masih mendapat pasar tersendiri,â€ ungkap Ketua Umum BOC selaku penyelenggara event, Edward.&nbsp;</p>', '521726_625241520836425_1642929404_n.jpg', '2016-12-19', 1, 'Balap Motor', ''),
(4, 1, 'HASIL KEJUARAAN GRASSTRACK DAN MINTRAIL BANTEN CUP OPEN 2016', '<p>Walaupun&nbsp;hujan turun di sirkuit Jambu Cisereh, Tigaraksa, Kab. Tangerang, kejuaraan Grasstrack dan Minitrail Banten Open 2016 yang diselenggarakan 30 Oktober kemarin&nbsp;tetap berjalan ketat. Para crosser yang datang berlomba mengikuti 15 kelas yang diperlombakan tetap tampil ngotot. Makanya, persaingan antar pembala di setiap kelas berjalan seru.&nbsp;</p><p>Untuk yang penasaran dengan hasil lomba Kejuaraan Grasstrack dan Minitrail Banten Cup Open 2016, berikut rinciannya:</p><p>Bebek Standar 116 cc Tangerang</p><p>1. (142) Arie CR. &nbsp; &nbsp; Tangerang. &nbsp; &nbsp; YMH</p><p>2. (11) Reza Fahlevi. &nbsp; Curug. &nbsp; &nbsp; &nbsp;YMH</p><p>3. (117) Fecun Costa. &nbsp; &nbsp; &nbsp;TNG. &nbsp; &nbsp; &nbsp;YMH</p><p>&nbsp;</p><p>FFA 250 cc - Tangerang</p><p>1. (150) Cece Hots. &nbsp; &nbsp; &nbsp; TNG. &nbsp; &nbsp; &nbsp; YMH</p><p>2. (175) Roni. &nbsp; &nbsp; &nbsp; &nbsp;Balaraja. &nbsp; &nbsp; &nbsp;YMH</p><p>3. (91) Denis D.R. &nbsp; Balaraja. &nbsp; &nbsp; &nbsp;KWSKI</p><p>&nbsp;</p><p>Minitrail U-12 - Open</p><p>1. (190) Vhery A. &nbsp; &nbsp; &nbsp;Pakem. &nbsp; &nbsp; &nbsp;-</p><p>2. (64) Yurico. &nbsp; &nbsp; &nbsp; &nbsp;Tangsel. &nbsp; &nbsp;-</p><p>3. (48) Dika. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;TNG. &nbsp; &nbsp; &nbsp; &nbsp;-</p><p>&nbsp;</p><p>FFA 250 - Open</p><p>1. (225) Diki Aja. &nbsp; &nbsp; &nbsp; &nbsp;KWSKI. &nbsp; &nbsp; &nbsp; Bekasi</p><p>2. (19) Deden H.D. &nbsp; &nbsp; &nbsp; KWSKI. &nbsp; &nbsp; &nbsp;TNG</p><p>3. (83) Chan Endri. &nbsp; &nbsp; &nbsp;KWSKI. &nbsp; &nbsp; TNG</p><p>&nbsp;</p><p>Enduro Build Up Hobby</p><p>1. (69) Dodi. &nbsp; &nbsp; &nbsp; TNG. &nbsp; &nbsp; &nbsp; KTM</p><p>2. (08) H. Idris. &nbsp; TNG. &nbsp; &nbsp; &nbsp;KTM</p><p>3. (11) Adink. &nbsp; &nbsp; &nbsp;TNG. &nbsp; &nbsp; &nbsp; KTM</p>', 'aa.jpg', '2016-12-19', 1, 'Balap Motor', '');

-- --------------------------------------------------------

--
-- Table structure for table `view_halaman`
--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `boc`.`view_halaman` AS select `boc`.`halaman`.`id_halaman` AS `id_halaman`,`boc`.`halaman`.`judul` AS `judul`,`boc`.`halaman`.`isi` AS `isi`,`boc`.`halaman`.`gambar` AS `gambar`,`boc`.`halaman`.`id_user` AS `id_user`,`boc`.`user`.`username` AS `username` from (`boc`.`halaman` left join `boc`.`user` on((`boc`.`user`.`id_user` = `boc`.`halaman`.`id_user`)));

--
-- Dumping data for table `view_halaman`
--

INSERT INTO `view_halaman` (`id_halaman`, `judul`, `isi`, `gambar`, `id_user`, `username`) VALUES
(1, 'SELAMAT DATANG DI WEBSTIE BALARAJA OTOMOTIF SPORTCLUB', '<br><div class="box_banner-3"></div>', 'Jadwal Kejurnas Grasstrack 2016 Agenda Terbaru.jpg', 1, ''),
(2, 'Tentang Kami', 'Salam Olah raga,Balaraja Otomotif Sport Club (BOC) adalah sebuah penyelenggara event dengan tema otomotif , bermula pada tahun 1999 diselenggarakannya kejuaraan Motocross &amp; Grasstrack didaerah Kabupaten Tangerang dengan suksesnya kegiatan tersebut kami terus membuat event untuk para pecinta otomotif dan mencari bakat dalam bidang olahraga Motocross &amp; Grasstrack, dari kejuaran tingkat pemula, sampai tingkat kejuaraan Nasional, event ini diselenggarakan dari tahun 1999 sampai 2010.&amp;Seiring berjalannya event Motocross &amp; Grasstrack, dan pada tahun 2004 kita membuat event Rally Wisata memperingati HUT Kabupaten Tangerang dan diikuti oleh 285 peserta.Pada Tahun 2013 â€œBanten Auto Showâ€ di Alam Sutera Serpong Tangerang Selatan untuk pertama kalinya event Kontes Mobil terbesar di Tangerang dengan jumlah peserta mencapai 150 orang dan di ikuti dari daerah Jabodetabek dan dari luar kota lainnya seperti Bandung.Dari sekian event yang terselenggara dan kami selalu bekerjasama dengan Ikatan Motor Indonesia Banten (IMI) dan instansi lainnya.', 'logo.png', 1, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
