﻿Imports System.Data
Imports System.Data.Sql
Imports System.Data.Odbc
Public Class ClsKoneksiDatabase
    Protected SQL As String
    Protected CONN As Odbc.OdbcConnection
    Protected Cmd As Odbc.OdbcCommand
    Protected DA As Odbc.OdbcDataAdapter
    Protected DS As DataSet
    Protected DT As DataTable
    Public Function OpenConn() As Boolean
        Try
            CONN = New Odbc.OdbcConnection("{DRIVER=MYSQL ODBC 3.51 DRIVER};SERVER=" & FrmKoneksi.TextBox1.Text & ";USERID=" & FrmKoneksi.TextBox2.Text & ";PASSWORD=" & FrmKoneksi.TextBox3.Text & ";DATABASE=" & FrmKoneksi.ComboBox1.Text & "")
            CONN.Open()
            If CONN.State <> ConnectionState.Open Then
                Return False
            Else
                Return True
            End If
        Catch
            FrmKoneksi.Show()
        End Try
    End Function
    Public Sub CloseConn()
        If Not IsNothing(CONN) Then
            CONN.Close()
            CONN = Nothing
        End If
    End Sub
    Public Function BACA(ByVal Query As String) As DataTable
        If Not OpenConn() Then
            MsgBox("Koneksi Gagal..!!", MsgBoxStyle.Critical, "Access Failed")
            Return Nothing
            Exit Function
        End If

        Cmd = New Odbc.OdbcCommand(Query, CONN)
        DA = New Odbc.OdbcDataAdapter
        DA.SelectCommand = Cmd

        DS = New Data.DataSet
        DA.Fill(DS)

        DT = DS.Tables(0)

        Return DT

        DT = Nothing
        DS = Nothing
        DA = Nothing
        Cmd = Nothing

        CloseConn()

    End Function
    Public Sub EKSEKUSI(ByVal Query As String)
        If Not OpenConn() Then
            MsgBox("Koneksi Gagal..!!", MsgBoxStyle.Critical, "Access Failed..!!")
            Exit Sub
        End If

        Cmd = New Odbc.OdbcCommand
        Cmd.Connection = CONN
        Cmd.CommandType = CommandType.Text
        Cmd.CommandText = Query
        Cmd.ExecuteNonQuery()
        Cmd = Nothing
        CloseConn()
    End Sub
End Class
