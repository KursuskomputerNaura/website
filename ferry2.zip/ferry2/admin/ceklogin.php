<?php
include "../config/koneksi.php";
$username = $_POST['username'];
$password = md5($_POST['password']);



  $query  = "SELECT * FROM user WHERE username='$username' AND password='$password'";
  $login  = $db->query($query);
  $ketemu = $login->num_rows;
  $r      = $login->fetch_array();

  // Apabila username dan password ditemukan (benar)
  if ($ketemu > 0){
    session_start();

    // bikin variabel session
    $_SESSION['namauser']    = $r['username'];
    $_SESSION['passuser']    = $r['password'];
    $_SESSION['namalengkap'] = $r['nama_lengkap'];
    $_SESSION['id']   = $r['id_user'];
   

    header("location:admin.php");
  }
  else{
    echo "<link href=\"css/style_login.css\" rel=\"stylesheet\" type=\"text/css\" />";
    echo "<div id=\"login\"><h1 class=\"fail\">Login Gagal! Username & Password salah.</h1>";
    echo "<p class=\"fail\"><a href=\"index.php\">Ulangi Lagi</a></p></div>";  
  }

?>
