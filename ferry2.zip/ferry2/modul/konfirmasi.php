<div class="container">
	<form name="myForm" method="post" action="?page=aksikonfirmasi" enctype="multipart/form-data">
	<legend>Form Konfirmasi</legend>
	<div class="control-group">
		<label for="">Nomor Pendaftaran anda</label>
		<input type="text" class="form-control" name="no_daftar" >
	</div>
	<div class="control-group">
		<label for="">Nama Lengkap</label>
		<input type="text" class="form-control" name="nama_lengkap">
	</div>

	<div class="control-group">
		<label for="">Bukti Pembayaran</label>
		<input type="file" name="gambar">
	</div>

	<button type="submit" class="btn btn-primary">Submit</button>
	<a href="index.php" class="btn btn-warning" id="kembali">Kembali</a>
</form>
</div>

