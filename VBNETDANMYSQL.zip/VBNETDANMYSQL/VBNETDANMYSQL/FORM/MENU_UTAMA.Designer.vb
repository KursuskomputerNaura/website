﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRM_MAIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FRM_MAIN))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Laporan = New System.Windows.Forms.TabPage
        Me.BTNLAPMASTER = New System.Windows.Forms.Button
        Me.Utility = New System.Windows.Forms.TabPage
        Me.BTNHAKAKSES = New System.Windows.Forms.Button
        Me.btnkonfigurasiserver = New System.Windows.Forms.Button
        Me.btnmanualbook = New System.Windows.Forms.Button
        Me.btngantipassword = New System.Windows.Forms.Button
        Me.btnbackupdata = New System.Windows.Forms.Button
        Me.btnlogoff = New System.Windows.Forms.Button
        Me.Keluar = New System.Windows.Forms.TabPage
        Me.btnkeluar = New System.Windows.Forms.Button
        Me.btnreturbeli = New System.Windows.Forms.Button
        Me.btnpembelian = New System.Windows.Forms.Button
        Me.btnreturjual = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.DataMAster = New System.Windows.Forms.TabPage
        Me.btnuser = New System.Windows.Forms.Button
        Me.btncustomer = New System.Windows.Forms.Button
        Me.btnsupplier = New System.Windows.Forms.Button
        Me.btnbarang = New System.Windows.Forms.Button
        Me.Transaksi = New System.Windows.Forms.TabPage
        Me.btnpenjualan = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Button21 = New System.Windows.Forms.Button
        Me.Button22 = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.PANEL = New System.Windows.Forms.StatusStrip
        Me.KOLOM1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.KOLOM2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.KOLOM3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.KOLOM4 = New System.Windows.Forms.ToolStripStatusLabel
        Me.Laporan.SuspendLayout()
        Me.Utility.SuspendLayout()
        Me.Keluar.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.DataMAster.SuspendLayout()
        Me.Transaksi.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PANEL.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Laporan
        '
        Me.Laporan.Controls.Add(Me.BTNLAPMASTER)
        Me.Laporan.Location = New System.Drawing.Point(4, 34)
        Me.Laporan.Name = "Laporan"
        Me.Laporan.Size = New System.Drawing.Size(609, 80)
        Me.Laporan.TabIndex = 2
        Me.Laporan.Text = "Laporan"
        Me.Laporan.UseVisualStyleBackColor = True
        '
        'BTNLAPMASTER
        '
        Me.BTNLAPMASTER.Dock = System.Windows.Forms.DockStyle.Left
        Me.BTNLAPMASTER.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNLAPMASTER.Location = New System.Drawing.Point(0, 0)
        Me.BTNLAPMASTER.Name = "BTNLAPMASTER"
        Me.BTNLAPMASTER.Size = New System.Drawing.Size(167, 80)
        Me.BTNLAPMASTER.TabIndex = 4
        Me.BTNLAPMASTER.Text = "LAP MASTER"
        Me.BTNLAPMASTER.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BTNLAPMASTER.UseVisualStyleBackColor = True
        '
        'Utility
        '
        Me.Utility.Controls.Add(Me.BTNHAKAKSES)
        Me.Utility.Controls.Add(Me.btnkonfigurasiserver)
        Me.Utility.Controls.Add(Me.btnmanualbook)
        Me.Utility.Controls.Add(Me.btngantipassword)
        Me.Utility.Controls.Add(Me.btnbackupdata)
        Me.Utility.Location = New System.Drawing.Point(4, 34)
        Me.Utility.Name = "Utility"
        Me.Utility.Size = New System.Drawing.Size(609, 80)
        Me.Utility.TabIndex = 3
        Me.Utility.Text = "Utility"
        Me.Utility.UseVisualStyleBackColor = True
        '
        'BTNHAKAKSES
        '
        Me.BTNHAKAKSES.Dock = System.Windows.Forms.DockStyle.Left
        Me.BTNHAKAKSES.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNHAKAKSES.Location = New System.Drawing.Point(525, 0)
        Me.BTNHAKAKSES.Name = "BTNHAKAKSES"
        Me.BTNHAKAKSES.Size = New System.Drawing.Size(127, 80)
        Me.BTNHAKAKSES.TabIndex = 8
        Me.BTNHAKAKSES.Text = "HAKAKASES"
        Me.BTNHAKAKSES.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BTNHAKAKSES.UseVisualStyleBackColor = True
        '
        'btnkonfigurasiserver
        '
        Me.btnkonfigurasiserver.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnkonfigurasiserver.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnkonfigurasiserver.Location = New System.Drawing.Point(366, 0)
        Me.btnkonfigurasiserver.Name = "btnkonfigurasiserver"
        Me.btnkonfigurasiserver.Size = New System.Drawing.Size(159, 80)
        Me.btnkonfigurasiserver.TabIndex = 7
        Me.btnkonfigurasiserver.Text = "KONFIGURASI SERVER"
        Me.btnkonfigurasiserver.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnkonfigurasiserver.UseVisualStyleBackColor = True
        '
        'btnmanualbook
        '
        Me.btnmanualbook.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnmanualbook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmanualbook.Location = New System.Drawing.Point(239, 0)
        Me.btnmanualbook.Name = "btnmanualbook"
        Me.btnmanualbook.Size = New System.Drawing.Size(127, 80)
        Me.btnmanualbook.TabIndex = 6
        Me.btnmanualbook.Text = "MANUAL BOOK"
        Me.btnmanualbook.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnmanualbook.UseVisualStyleBackColor = True
        '
        'btngantipassword
        '
        Me.btngantipassword.Dock = System.Windows.Forms.DockStyle.Left
        Me.btngantipassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btngantipassword.Location = New System.Drawing.Point(112, 0)
        Me.btngantipassword.Name = "btngantipassword"
        Me.btngantipassword.Size = New System.Drawing.Size(127, 80)
        Me.btngantipassword.TabIndex = 5
        Me.btngantipassword.Text = "GANTI PASSWORD"
        Me.btngantipassword.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btngantipassword.UseVisualStyleBackColor = True
        '
        'btnbackupdata
        '
        Me.btnbackupdata.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnbackupdata.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbackupdata.Location = New System.Drawing.Point(0, 0)
        Me.btnbackupdata.Name = "btnbackupdata"
        Me.btnbackupdata.Size = New System.Drawing.Size(112, 80)
        Me.btnbackupdata.TabIndex = 4
        Me.btnbackupdata.Text = "BACKUP DATA"
        Me.btnbackupdata.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnbackupdata.UseVisualStyleBackColor = True
        '
        'btnlogoff
        '
        Me.btnlogoff.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnlogoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlogoff.Location = New System.Drawing.Point(96, 0)
        Me.btnlogoff.Name = "btnlogoff"
        Me.btnlogoff.Size = New System.Drawing.Size(87, 80)
        Me.btnlogoff.TabIndex = 5
        Me.btnlogoff.Text = "Button19"
        Me.btnlogoff.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnlogoff.UseVisualStyleBackColor = True
        '
        'Keluar
        '
        Me.Keluar.Controls.Add(Me.btnlogoff)
        Me.Keluar.Controls.Add(Me.btnkeluar)
        Me.Keluar.Location = New System.Drawing.Point(4, 34)
        Me.Keluar.Name = "Keluar"
        Me.Keluar.Size = New System.Drawing.Size(609, 80)
        Me.Keluar.TabIndex = 4
        Me.Keluar.Text = "Keluar"
        Me.Keluar.UseVisualStyleBackColor = True
        '
        'btnkeluar
        '
        Me.btnkeluar.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnkeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnkeluar.Location = New System.Drawing.Point(0, 0)
        Me.btnkeluar.Name = "btnkeluar"
        Me.btnkeluar.Size = New System.Drawing.Size(96, 80)
        Me.btnkeluar.TabIndex = 4
        Me.btnkeluar.Text = "Button20"
        Me.btnkeluar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnkeluar.UseVisualStyleBackColor = True
        '
        'btnreturbeli
        '
        Me.btnreturbeli.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnreturbeli.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreturbeli.Image = CType(resources.GetObject("btnreturbeli.Image"), System.Drawing.Image)
        Me.btnreturbeli.Location = New System.Drawing.Point(549, 3)
        Me.btnreturbeli.Name = "btnreturbeli"
        Me.btnreturbeli.Size = New System.Drawing.Size(185, 74)
        Me.btnreturbeli.TabIndex = 7
        Me.btnreturbeli.Text = "Retur Beli"
        Me.btnreturbeli.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnreturbeli.UseVisualStyleBackColor = True
        '
        'btnpembelian
        '
        Me.btnpembelian.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnpembelian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpembelian.Image = CType(resources.GetObject("btnpembelian.Image"), System.Drawing.Image)
        Me.btnpembelian.Location = New System.Drawing.Point(364, 3)
        Me.btnpembelian.Name = "btnpembelian"
        Me.btnpembelian.Size = New System.Drawing.Size(185, 74)
        Me.btnpembelian.TabIndex = 6
        Me.btnpembelian.Text = "Pembelian"
        Me.btnpembelian.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnpembelian.UseVisualStyleBackColor = True
        '
        'btnreturjual
        '
        Me.btnreturjual.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnreturjual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreturjual.Image = CType(resources.GetObject("btnreturjual.Image"), System.Drawing.Image)
        Me.btnreturjual.Location = New System.Drawing.Point(179, 3)
        Me.btnreturjual.Name = "btnreturjual"
        Me.btnreturjual.Size = New System.Drawing.Size(185, 74)
        Me.btnreturjual.TabIndex = 5
        Me.btnreturjual.Text = "Retur Jual"
        Me.btnreturjual.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnreturjual.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(201, 201)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(0, 267)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(207, 33)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Label2"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 229)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(207, 38)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.HighlightText
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(207, 229)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Profil Operator"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.DataMAster)
        Me.TabControl1.Controls.Add(Me.Transaksi)
        Me.TabControl1.Controls.Add(Me.Laporan)
        Me.TabControl1.Controls.Add(Me.Utility)
        Me.TabControl1.Controls.Add(Me.Keluar)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabControl1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(207, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(617, 118)
        Me.TabControl1.TabIndex = 5
        '
        'DataMAster
        '
        Me.DataMAster.Controls.Add(Me.btnuser)
        Me.DataMAster.Controls.Add(Me.btncustomer)
        Me.DataMAster.Controls.Add(Me.btnsupplier)
        Me.DataMAster.Controls.Add(Me.btnbarang)
        Me.DataMAster.Location = New System.Drawing.Point(4, 34)
        Me.DataMAster.Name = "DataMAster"
        Me.DataMAster.Padding = New System.Windows.Forms.Padding(3)
        Me.DataMAster.Size = New System.Drawing.Size(609, 80)
        Me.DataMAster.TabIndex = 0
        Me.DataMAster.Text = "Data Master"
        Me.DataMAster.UseVisualStyleBackColor = True
        '
        'btnuser
        '
        Me.btnuser.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnuser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnuser.Image = CType(resources.GetObject("btnuser.Image"), System.Drawing.Image)
        Me.btnuser.Location = New System.Drawing.Point(375, 3)
        Me.btnuser.Name = "btnuser"
        Me.btnuser.Size = New System.Drawing.Size(124, 74)
        Me.btnuser.TabIndex = 3
        Me.btnuser.Text = "User"
        Me.btnuser.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnuser.UseVisualStyleBackColor = True
        '
        'btncustomer
        '
        Me.btncustomer.Dock = System.Windows.Forms.DockStyle.Left
        Me.btncustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncustomer.Image = CType(resources.GetObject("btncustomer.Image"), System.Drawing.Image)
        Me.btncustomer.Location = New System.Drawing.Point(251, 3)
        Me.btncustomer.Name = "btncustomer"
        Me.btncustomer.Size = New System.Drawing.Size(124, 74)
        Me.btncustomer.TabIndex = 2
        Me.btncustomer.Text = "Customer"
        Me.btncustomer.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btncustomer.UseVisualStyleBackColor = True
        '
        'btnsupplier
        '
        Me.btnsupplier.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnsupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsupplier.Image = CType(resources.GetObject("btnsupplier.Image"), System.Drawing.Image)
        Me.btnsupplier.Location = New System.Drawing.Point(127, 3)
        Me.btnsupplier.Name = "btnsupplier"
        Me.btnsupplier.Size = New System.Drawing.Size(124, 74)
        Me.btnsupplier.TabIndex = 1
        Me.btnsupplier.Text = "Supplier"
        Me.btnsupplier.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsupplier.UseVisualStyleBackColor = True
        '
        'btnbarang
        '
        Me.btnbarang.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnbarang.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnbarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbarang.Image = CType(resources.GetObject("btnbarang.Image"), System.Drawing.Image)
        Me.btnbarang.Location = New System.Drawing.Point(3, 3)
        Me.btnbarang.Name = "btnbarang"
        Me.btnbarang.Size = New System.Drawing.Size(124, 74)
        Me.btnbarang.TabIndex = 0
        Me.btnbarang.Text = "Barang"
        Me.btnbarang.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnbarang.UseVisualStyleBackColor = False
        '
        'Transaksi
        '
        Me.Transaksi.Controls.Add(Me.btnreturbeli)
        Me.Transaksi.Controls.Add(Me.btnpembelian)
        Me.Transaksi.Controls.Add(Me.btnreturjual)
        Me.Transaksi.Controls.Add(Me.btnpenjualan)
        Me.Transaksi.Location = New System.Drawing.Point(4, 34)
        Me.Transaksi.Name = "Transaksi"
        Me.Transaksi.Padding = New System.Windows.Forms.Padding(3)
        Me.Transaksi.Size = New System.Drawing.Size(609, 80)
        Me.Transaksi.TabIndex = 1
        Me.Transaksi.Text = "Transaksi"
        Me.Transaksi.UseVisualStyleBackColor = True
        '
        'btnpenjualan
        '
        Me.btnpenjualan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnpenjualan.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnpenjualan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpenjualan.Image = CType(resources.GetObject("btnpenjualan.Image"), System.Drawing.Image)
        Me.btnpenjualan.Location = New System.Drawing.Point(3, 3)
        Me.btnpenjualan.Name = "btnpenjualan"
        Me.btnpenjualan.Size = New System.Drawing.Size(176, 74)
        Me.btnpenjualan.TabIndex = 4
        Me.btnpenjualan.Text = "PENJUALAN"
        Me.btnpenjualan.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnpenjualan.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.HighlightText
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(207, 683)
        Me.Panel1.TabIndex = 4
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Button21)
        Me.Panel3.Controls.Add(Me.Button22)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 433)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(207, 100)
        Me.Panel3.TabIndex = 8
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.White
        Me.Button21.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Image = CType(resources.GetObject("Button21.Image"), System.Drawing.Image)
        Me.Button21.Location = New System.Drawing.Point(97, 0)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(107, 100)
        Me.Button21.TabIndex = 3
        Me.Button21.Text = "HUTANG"
        Me.Button21.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.White
        Me.Button22.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Image = CType(resources.GetObject("Button22.Image"), System.Drawing.Image)
        Me.Button22.Location = New System.Drawing.Point(0, 0)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(97, 100)
        Me.Button22.TabIndex = 2
        Me.Button22.Text = "PIUTANG"
        Me.Button22.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 333)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(207, 100)
        Me.Panel2.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(97, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(107, 100)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "ORDER"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(0, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(97, 100)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "STOK"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(0, 300)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(207, 33)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Label3"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PANEL
        '
        Me.PANEL.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KOLOM1, Me.KOLOM2, Me.KOLOM3, Me.KOLOM4})
        Me.PANEL.Location = New System.Drawing.Point(207, 661)
        Me.PANEL.Name = "PANEL"
        Me.PANEL.Size = New System.Drawing.Size(617, 22)
        Me.PANEL.TabIndex = 7
        Me.PANEL.Text = "StatusStrip1"
        '
        'KOLOM1
        '
        Me.KOLOM1.Name = "KOLOM1"
        Me.KOLOM1.Size = New System.Drawing.Size(55, 17)
        Me.KOLOM1.Text = "KOLOM1"
        '
        'KOLOM2
        '
        Me.KOLOM2.Name = "KOLOM2"
        Me.KOLOM2.Size = New System.Drawing.Size(55, 17)
        Me.KOLOM2.Text = "KOLOM2"
        '
        'KOLOM3
        '
        Me.KOLOM3.Name = "KOLOM3"
        Me.KOLOM3.Size = New System.Drawing.Size(55, 17)
        Me.KOLOM3.Text = "KOLOM3"
        '
        'KOLOM4
        '
        Me.KOLOM4.Name = "KOLOM4"
        Me.KOLOM4.Size = New System.Drawing.Size(55, 17)
        Me.KOLOM4.Text = "KOLOM4"
        '
        'FRM_MAIN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(824, 683)
        Me.Controls.Add(Me.PANEL)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Panel1)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.IsMdiContainer = True
        Me.Name = "FRM_MAIN"
        Me.Text = "MENU UTAMA APLIKASI  POST"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Laporan.ResumeLayout(False)
        Me.Utility.ResumeLayout(False)
        Me.Keluar.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.DataMAster.ResumeLayout(False)
        Me.Transaksi.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.PANEL.ResumeLayout(False)
        Me.PANEL.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Laporan As System.Windows.Forms.TabPage
    Friend WithEvents BTNLAPMASTER As System.Windows.Forms.Button
    Friend WithEvents Utility As System.Windows.Forms.TabPage
    Friend WithEvents btnkonfigurasiserver As System.Windows.Forms.Button
    Friend WithEvents btnmanualbook As System.Windows.Forms.Button
    Friend WithEvents btngantipassword As System.Windows.Forms.Button
    Friend WithEvents btnbackupdata As System.Windows.Forms.Button
    Friend WithEvents btnlogoff As System.Windows.Forms.Button
    Friend WithEvents Keluar As System.Windows.Forms.TabPage
    Friend WithEvents btnkeluar As System.Windows.Forms.Button
    Friend WithEvents btnreturbeli As System.Windows.Forms.Button
    Friend WithEvents btnpembelian As System.Windows.Forms.Button
    Friend WithEvents btnreturjual As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents DataMAster As System.Windows.Forms.TabPage
    Friend WithEvents btnuser As System.Windows.Forms.Button
    Friend WithEvents btncustomer As System.Windows.Forms.Button
    Friend WithEvents btnsupplier As System.Windows.Forms.Button
    Friend WithEvents btnbarang As System.Windows.Forms.Button
    Friend WithEvents Transaksi As System.Windows.Forms.TabPage
    Friend WithEvents btnpenjualan As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents BTNHAKAKSES As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents PANEL As System.Windows.Forms.StatusStrip
    Friend WithEvents KOLOM1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents KOLOM2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents KOLOM3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents KOLOM4 As System.Windows.Forms.ToolStripStatusLabel
End Class
