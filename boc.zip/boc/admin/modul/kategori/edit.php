<?php
akses(); 
$edit = $db->query("select * from kategori where id_kategori='$_GET[id]'");
$r = $edit->fetch_array();
?>
<div class="mws-panel grid_8">
                    <div class="mws-panel-header">
                        <span>Edit Kategori</span>
                    </div>
                    <div class="mws-panel-body no-padding">
                        <form class="mws-form" action="?page=kategori&act=update">
                        <input type="hidden" name="id" value="<?php echo $r['id_kategori']; ?>">
                            <div class="mws-form-inline">
                                <div class="mws-form-row">
                                    <label class="mws-form-label">Kategori</label>
                                    <div class="mws-form-item">
                                        <input type="text" class="small" name="kategori" value="<?php echo $r['kategori']; ?>">
                                    </div>
                                </div>
                                
                            </div>
                            <div class="mws-button-row">
                                <input type="submit" value="Submit" class="btn btn-danger">
                                <input type="reset" value="Reset" class="btn ">
                            </div>
                        </form>
                    </div>      
                </div>



                