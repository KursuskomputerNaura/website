<div class="mws-panel grid_8">
    <div class="mws-panel-header">
         <span><i class="icon-magic"></i> Beranda</span>
     </div>
    <div class="mws-panel-body no-padding">
        <h1 align="center">Selamat Datang <?php echo $_SESSION['namalengkap']; ?></h1>  
    </div>
</div>

