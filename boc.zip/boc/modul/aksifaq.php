<?php 
	$db->query("INSERT INTO faq SET nama_lengkap='$_POST[nama_lengkap]',
		                               email='$_POST[email]',
		                               pesan='$_POST[pesan]'");
	echo "<script>
           alert('Pesan berhasil dikirim');
           window.location='?page=faq';
	</script>";
?>