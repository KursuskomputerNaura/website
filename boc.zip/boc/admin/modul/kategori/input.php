<?php
akses(); 
$db->query("INSERT INTO kategori SET kategori='$_POST[kategori]'");
header('location:?page=kategori');
?>