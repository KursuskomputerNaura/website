<?php
akses();
$gambar  = $_FILES['gambar']['name'];

if (empty($gambar)) {
	$input = $db->query("UPDATE event SET id_kategori='$_POST[id_kategori]',
								 judul='$_POST[judul]',
								 isi='$_POST[isi]'
								 WHERE id_event='$_POST[id]'");
}else{
	//untuk menghapus gambar sebelumnya
	$edit = $db->query("select * from event where id_event='$_POST[id]'");
	$r = $edit->fetch_array();
	$file = "../gambar/$r[gambar]";
	unlink($file);
	//untuk upload gambar baru
	move_uploaded_file($_FILES['gambar']['tmp_name'], "../gambar/$gambar");
	$input = $db->query("UPDATE event SET judul='$_POST[judul]',
								 			isi='$_POST[isi]',
								 			gambar='$gambar'
											WHERE id_event='$_POST[id]'");
}


header('location:?page=event');
?>