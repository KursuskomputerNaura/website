﻿Imports System.Data.Odbc
Public Class ReturJual

    Sub NOMOR_RETURotomatis()
        Call koneksi()
        cmd = New OdbcCommand("select * from TBL_RETURJUAL where NOMOR_RETUR in(select max(NOMOR_RETUR) from TBL_RETURJUAL)", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            Label2.Text = "RJ" + Format(Now, "yyMMdd") + "01"
        Else
            If Microsoft.VisualBasic.Mid(dr.Item("NOMOR_RETUR"), 3, 6) = Format(Now, "yyMMdd") Then
                Label2.Text = Microsoft.VisualBasic.Right(dr.Item("NOMOR_RETUR"), 8) + 1
                Label2.Text = "RJ" + Label2.Text
            Else
                Label2.Text = "RJ" + Format(Now, "yyMMdd") + "01"
            End If
        End If
    End Sub

    Private Sub pembelian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        Call NOMOR_RETURotomatis()
        Label4.Text = Today

    End Sub

    Sub HitungBarang()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DGV.RowCount - 1
            hitung = hitung + DGV.Rows(baris).Cells(3).Value
            Label13.Text = hitung
        Next
    End Sub


    Private Sub DGV_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellEndEdit


        If e.ColumnIndex = 3 Then
            If DGV.Rows(e.RowIndex).Cells(3).Value > DGV.Rows(e.RowIndex).Cells(2).Value Then
                MsgBox("jumlah retur terlalu banyak")
                DGV.Rows(e.RowIndex).Cells(3).Value = 0
                SendKeys.Send("{up}")
                Exit Sub
            Else
                DGV.CurrentCell = DGV(4, DGV.CurrentCell.RowIndex)
                SendKeys.Send("{up}")
                Call HitungBarang()
            End If

        End If
    End Sub

    Private Sub DGV_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DGV.KeyPress
        On Error Resume Next
        If e.KeyChar = Chr(27) Then
            DGV.Rows.RemoveAt(DGV.CurrentCell.RowIndex)
            Call HitungBarang()

        End If

        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            Call koneksi()
            cmd = New OdbcCommand("select * from TBL_RETURJUAL where faktur='" & TextBox1.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                Label7.Text = dr.Item("Tanggal")
                Label9.Text = dr.Item("kode_customer")
                Call koneksi()
                cmd = New OdbcCommand("select * from tblcustomer where kode_customer='" & Label9.Text & "'", conn)
                dr = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    Label12.Text = dr.Item("nama_customer")
                End If

                Call koneksi()
                da = New OdbcDataAdapter("select Kode_Barang,Nama_Barang,Jumlah from tbldetailjual where faktur='" & TextBox1.Text & "'", conn)
                ds = New DataSet
                da.Fill(ds)
                DGV.DataSource = ds.Tables(0)
                DGV.Columns.Add("QTY", "Qty Retur")
                DGV.Columns.Add("Ket", "Keterangan")
                DGV.Focus()
                DGV.CurrentCell = DGV(3, DGV.CurrentCell.RowIndex)
            Else
                MsgBox("nomor faktur tidak terdaftar")
                Label7.Text = ""
                Label9.Text = ""
                Label12.Text = ""
            End If
        End If
    End Sub



    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or Label13.Text = "" Then
            MsgBox("Transaksi belum lengkap")
            Exit Sub
        Else
            Call koneksi()
            Dim simpan1 As String = "insert into TBL_RETURJUAL values ('" & Label2.Text & "','" & Label4.Text & "','" & TextBox1.Text & "','" & Label13.Text & "','" & Label9.Text & "','" & FRM_MAIN.Label1.Text & "')"
            cmd = New OdbcCommand(simpan1, conn)
            cmd.ExecuteNonQuery()

            For baris As Integer = 0 To DGV.RowCount - 2
                Call koneksi()
                Dim simpan2 As String = "insert into TBLdetailRETURjual values ('" & Label2.Text & "','" & DGV.Rows(baris).Cells(0).Value & "','" & DGV.Rows(baris).Cells(1).Value & "','" & DGV.Rows(baris).Cells(3).Value & "','" & DGV.Rows(baris).Cells(4).Value & "')"
                cmd = New OdbcCommand(simpan2, conn)
                cmd.ExecuteNonQuery()

                Call koneksi()
                cmd = New OdbcCommand("select * from tblbarang where kode_barang='" & DGV.Rows(baris).Cells(0).Value & "'", conn)
                dr = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    Call koneksi()
                    Dim kurangistok As String = "update tblbarang set stok='" & dr.Item("stok") + DGV.Rows(baris).Cells(3).Value & "' where kode_barang='" & DGV.Rows(baris).Cells(0).Value & "'"
                    cmd = New OdbcCommand(kurangistok, conn)
                    cmd.ExecuteNonQuery()
                End If
            Next
            Call Bersihkan()
            Call NOMOR_RETURotomatis()

        End If
    End Sub

    Sub Bersihkan()

        Label7.Text = ""
        Label9.Text = ""
        TextBox1.Text = ""
        Label12.Text = ""
        Label13.Text = ""
        DGV.Columns.Clear()

    End Sub


End Class