<?php 
$edit = $db->query("select * from menuadmin where id='$_GET[id]'");
$r = $edit->fetch_array();
?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Add Menu</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=menu&act=update' method="post">
                        <input type='hidden' name="id" value="<?php echo $r['id']; ?>">
                            <div class='mws-form-inline'>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Menu Induk</label>
                                    <div class='mws-form-item'>
                                        <select class='small' name="parent_id">
                                            <option value="<?php echo $r['parent_id']; ?>"><?php echo $r['title']; ?></option>
                                            <?php 
                                                $parent = $db->query("select * from menuadmin");
                                                while ($p = $parent->fetch_array()) {
                                                   echo "<option value='$p[parent_id]'>$p[title]</option>";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Title</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="title"  class='mws-textinput' value="<?php echo $r['title']; ?>">
                                    </div>
                                </div>
                                <div id="elfinder"></div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Url</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="url" class='mws-textinput' value="<?php echo $r['url']; ?>">
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Icon</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="icon" class='mws-textinput' value="<?php echo $r['icon']; ?>">
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Menu Order</label>
                                    <div class='mws-form-item'>
                                <input type='text' name="menu_order" class='mws-textinput' value="<?php echo $r['menu_order']; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=menu' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
</div>