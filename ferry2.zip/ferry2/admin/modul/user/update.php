<?php
akses();
$db->query("UPDATE user SET nama_lengkap='$_POST[nama_lengkap]',
								 username='$_POST[username]',
								 password='".md5($_POST[password])."',
								 email='$_POST[email]'
								 WHERE id_user='$_POST[id]'");
header('location:?page=user');
?>