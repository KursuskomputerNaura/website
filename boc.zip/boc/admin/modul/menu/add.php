<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Add Menu</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=menu&act=input' method="post">
                            <div class='mws-form-inline'>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Menu Induk</label>
                                    <div class='mws-form-item'>
                                        <select class='small' name="parent_id">
                                            <option>Menu Induk</option>
                                            <?php 
                                                $parent = $db->query("select * from menuadmin");
                                                while ($p = $parent->fetch_array()) {
                                                   echo "<option value='$p[parent_id]'>$p[title]</option>";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Title</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="title"  class='mws-textinput'>
                                    </div>
                                </div>
                                <div id="elfinder"></div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Url</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="url" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Icon</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="icon" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Menu Order</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="menu_order" class='mws-textinput'>
                                    </div>
                                </div>
                            </div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=menu' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
                </div>