<?php 
akses();
?>
<div class="mws-panel grid_8">
                    <div class="mws-panel-header">
                        <span>Add event</span>
                    </div>
                    <div class="mws-panel-body no-padding">
                        <form class="mws-form" action="?page=event&act=input" method="post" enctype="multipart/form-data">
                            <div class="mws-form-inline">
                                <div class="mws-form-row">
                                    <label class="mws-form-label">Judul</label>
                                    <div class="mws-form-item">
                                        <input type="text" class='mws-textinput' name="judul">
                                    </div>
                                </div>
                                <div class="mws-form-row">
                                    <label class="mws-form-label">Isi</label>
                                    <div class="mws-form-item">
                                        <textarea rows="" cols="" class="large" id="elrte" name="isi"></textarea>
                                    </div>
                                </div>
                                
                               <div class="mws-form-row">
                                    <label class="mws-form-label">Gambar</label>
                                    <div class="mws-form-item">
                                        <input type="file" class="small" name="gambar">
                                    </div>
                                </div>
                            </div>
                            <div class="mws-button-row">
                                <input type="submit" value="Submit" class="mws-btn btn-danger">
                                <input type="reset" value="Reset" class="mws-btn ">
                            </div>
                        </form>
                    </div>      
                </div>



                