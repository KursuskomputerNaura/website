<?php 
$edit = $db->query("select * from user where id_user='$_GET[id]'");
$r = $edit->fetch_array();
?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Add user</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=user&act=gantipassword' method="post">
                        <input type='hidden' name="id" value="<?php echo $r['id_user']; ?>">
                            <div class='mws-form-inline'>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Password Lama</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="passwordlama"  class='mws-textinput'>
                                    </div>
                                </div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Password Baru</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="passwordbaru" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Konfirmasi</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="konfirmasi" class='mws-textinput'>
                                    </div>
                                </div>

                                
                            </div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=user' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
                </div>