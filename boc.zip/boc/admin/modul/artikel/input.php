<?php
akses();
$tanggal = date('Y-m-d');
$id_user = $_SESSION['id'];
$gambar  = $_FILES['gambar']['name'];
move_uploaded_file($_FILES['gambar']['tmp_name'], "../gambar/$gambar");
$input = $db->query("INSERT INTO artikel SET id_kategori='$_POST[id_kategori]',
								 judul='$_POST[judul]',
								 isi='$_POST[isi]',
								 gambar='$gambar',
								 tanggal='$tanggal',
								 id_user='$id_user'");

header('location:?page=artikel');
?>