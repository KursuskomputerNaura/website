<div class="row-fluid" style="margin-top: -50px;">
  <div class="vc_banner block">
    <div class="wrapper">
      <div class="row-fluid">
        <div class="span12">
          <div class="vc_metro-wrapper">
            <div class="vc_metro-slider-outer">
              <div class="viewport">
                <div class="overview">
                  <div class="vc_metro-slider">
                    <ul>
                      <li class="odd">
                        <ul>
                          <li class="box type-1 anim-slide-right"> <a href="?page=daftar"> <img alt="web rally" src="img/metro-img/logo.png">
                            <div class="mouse-over">
                              <div class="content">
                                <div class="text">
                                  <h2>Panduan <span class="vc_main-color"> REGISTRASI </span> </h2>
                                  <p>1 - Klik Tombol pendaftaran </p>
                                  <p>2 - Lakukan pembayaran</p>
                                  <p>3 - Konfirmasi pembayaran melalui form konfirmasi</p>
                                  <p>4 - Cek pengumuman jadwal acara</p>
                                  <div class="vc_btn" id="daftar"> Register </div>
                                </div>
                              </div>
                            </div>
                            </a> </li>
                        </ul>
                      </li>
                      <li class="even">
                        <ul>
                          <li class="box type-2 anim-slide-left"> <a href="?page=daftar"> <img alt="" src="img/metro-img/web_design_02.png">
                            <div class="mouse-over bg-none">
                              <div class="content">
                                <div class="text">
                                  <h2> Pendaftaran <span class="vc_main-color"> </span> </h2>
                                  <p>Klik Tombol di bawah ini untuk melakukan pendaftaran</p>
                                  <div class="vc_btn" id="lihat"> Calon Peserta </div>
                                </div>
                              </div>
                            </div>
                            </a> </li>
                          <li class="box type-3 anim-rotate"> <a href="#"> <img alt="" src="img/metro-img/web_design_03.png">
                            <div class="mouse-over bg-none">
                              <div class="content"> <img alt="" src="img/metro-img/web_design_hover_03.png"> </div>
                            </div>
                            </a> </li>
                          <li class="box type-3 none"> <a href="#"> <img alt="" src="img/metro-img/web_design_04.png"> </a> </li>
                          <li class="box type-3 anim-hover"> <a href="#"> <img alt="" src="img/metro-img/web_design_05.png">
                            <div class="mouse-over bg-none">
                              <div class="content"> <img alt="" src="img/metro-img/web_design_hover_05.png"> </div>
                            </div>
                            </a> </li>
                          <li class="box type-2  anim-slide-top"> <a href="?page=konfirmasi"> <img alt="" src="img/metro-img/web_design_06.png">
                            <div class="mouse-over  bg-none">
                              <div class="content">
                                <div class="text">
                                  <h2> Konfirmasi Pendaftaran anda <span class="vc_main-color"></span> </h2>
                                  <p> Klik link dibawah ini Mengkonfirmasi Pembayaran anda</p>
                                  <div class="vc_btn">Konfirmasi</div>
                                </div>
                              </div>
                            </div>
                            </a> </li>
                          <li class="box type-3 none"> <a href="#"> <img alt="" src="img/metro-img/web_design_07.png"> </a> </li>
                        </ul>
                      </li>
                      <li class="odd">
                        <ul>
                          <li class="box type-1  anim-slide-left"> <a href="?page=pengumuman"> <img alt="" src="img/metro-img/pengumuman.png">
                            <div class="mouse-over bg-none">
                              <div class="content">
                                <div class="text">
                                  <h2>Pengumuman Acara<span class="vc_main-color"></span> </h2>
                                  <p>Pengumuman acara banten Rally Wisata</p>
                                  <div class="vc_btn">Lihat Pengumuman</div>
                                </div>
                              </div>
                            </div>
                            </a> </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                  <!-- vc_metro-slider --> 
                </div>
                <!-- overview --> 
              </div>
              <!-- viewport -->
              <div class="scrollbar">
                <div class="track">
                  <div class="thumb vc_bg-color">
                    <div class="btn-slide"> </div>
                    <div class="end"> </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- vc_metro-slider-outer --> 
          </div>
          <!-- vc_metro-wrapper --> 
        </div>
        <!-- span12 --> 
      </div>
      <!-- row-fluid --> 
    </div>
    <!-- wrapper --> 
  </div>
</div>