<?php
akses();
if ($_POST['passwordlama']<>$_SESSION['passuser']) {
	echo "<script>
			alert('password lama salah');
			window.location='?page=user&act=changepassword&id=$_POST[id]';
	      </script>";
}elseif ($_POST['passwordbaru']<>$_POST['konfirmasi']) {
	echo "<script>
			alert('password baru tidak cocok!');
			window.location='?page=user&act=changepassword&id=$_POST[id]';
	      </script>";
}else{
	$db->query("UPDATE user SET password='$_POST[passwordbaru]'WHERE id_user='$_POST[id]'");
	header('location:?page=user');
}

?>