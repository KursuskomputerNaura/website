<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Add user</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=user&act=input' method="post">
                            <div class='mws-form-inline'>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Nama Lengkap</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="nama_lengkap"  class='mws-textinput'>
                                    </div>
                                </div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Username</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="username" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Password</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="password" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Email</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="email" class='mws-textinput'>
                                    </div>
                                </div>
                            </div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=user' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
                </div>