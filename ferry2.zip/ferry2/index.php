
<?php 
include 'config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/index.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta charset="utf-8" />

<!-- InstanceBeginEditable name="doctitle" -->
<title>IMI event </title>
<!-- InstanceEndEditable -->
<meta name="keywords" content="MPLUS International" />
<meta name="description" content="MPLUS - Bisnis Membantu Bisnis">
<meta name="author" content="MPLUS">
<link rel="shorcut icon"  href="img/favicon.ico">

<!-- Set the viewport width to device width for mobile -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Fav and touch icons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="img/ico/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="img/ico/favicon.ico">


<!-- CSS -->

<!-- Fonts CSS -->
<link href="css/fonts.css"  rel='stylesheet' type='text/css'>
<!--[if lte IE 9]><link type='text/css' rel="stylesheet" href="css/fonts/ie-google-webfont.css"><![endif]-->

<!-- Bootstrap & FontAwesome CSS -->
<link href='css/bootstrap.min.css' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.min.css" rel="stylesheet" type='text/css'>
<!--[if IE 7]><link type='text/css' rel="stylesheet" href="css/font-awesome-ie7.min.css"><![endif]-->

<!-- Plugin CSS -->
<link href="css/pretty.css" rel="stylesheet" type='text/css'>
<link href="css/isotope.css" rel="stylesheet" type='text/css'>
<link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />

<!-- Theme CSS -->
<link href='css/theme.css' rel='stylesheet' type='text/css'>

<!-- Responsive CSS -->
<link href='css/bootstrap-responsive.min.css' rel='stylesheet' type='text/css'>
<link href='css/theme-responsive.css' rel='stylesheet' type='text/css'>

<!-- Design Mode CSS -->
<link id="link-design" href='css/mode-slash.css' rel='stylesheet' type='text/css'>
<link id="link-color" href='css/color-blue.css' rel='stylesheet' type='text/css'>

<!-- Custom CSS -->
<link href='custom/custom.css' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/datatable.css">
<link rel="stylesheet" href="css/bsdate.css" />

<!-- SCRIPTS -->

<!--[if (gte IE 6)&(lte IE 8)]><script src="js/selectivizr-min.js"></script><![endif]-->
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

</head>
<body class="clearfix" data-smooth-scrolling="1">
<div class="vc_body">
  <header>
    <div class="container">
      <div class="row-fluid">
        <div class="span12">
          <nav class="vc_menu pull-left"> <a href="index.php" class="logo pull-left"> <img alt="logo" src="img/logo.jpg" width="100" style="margin-top: 120px;"> </a>
            <div class="navbar navbar-inverse">
              <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".vc_primary-menu"> <span class="icon-bar"> </span> <span class="icon-bar"> </span> <span class="icon-bar"> </span> </button>
            </div>
            <div class="vc_primary-menu pull-left">
             <!--  -->
              <!-- Head menu search form ends --> 
            </div>
            <!-- <div class="vc_menu-search-wrapper pull-right">
              <form class="vc_menu-search" method="post" action="http://metcreative.com/demo/demo_news24/sites/magazine/index.php?">
                <input type="text" name="search" class="vc_menu-search-text" required placeholder="Search">
                <div class="vc_menu-search-submit"> </div>
              </form>
            </div> -->
            <!-- In menu search form ends --> 
          </nav>
          <div class="clearfix"> </div>
          
        </div>
      </div>
      <!-- <div class="vc_sub-menu-bg"> </div> -->
    </div>
    <!-- <div class="vc_menu-bg"> </div> -->
  </header>
  <!-- Header Ends --> 
  
  <!-- InstanceBeginEditable name="content" -->


<?php 
$page = isset($_GET['page']) ? $_GET['page']:'';
if ($page) {
  include "modul/$page.php";
}else{
  include "modul/home.php";
}
?>

  <!-- vc_banner -->
  
  <!-- InstanceEndEditable --> 
  
  <!-- Middle Content Ends -->
  <footer>
    <div class="vc_footer-links">
      <div class="wrapper">
      </div>
    </div>
    <div class="vc_bottom">
      <div class="wrapper">
          <div class="vc_footer-line"> </div>
          <div class="bg">
            <div class="row-fluid">
              <div class="span6">
                <div class="copyright pull-left">
                  <h5> Copyright &copy;2016  Banten Racing Club - All Rights Reserved </h5>
                </div>
              </div>
              <div class="span6">
                <div class="menu pull-right"> <a href="index.php">Home</a> <a href="?page=about"> About </a> <a href="?page=contact"> Contact </a>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </footer>
</div>
<a class="back-top" href="#" id="back-top"> <i class="icon-chevron-up icon-white"> </i> </a> 

<!-- Javascript =============================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="js/modernizr.js"></script> 
<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/retina.js"></script> 
<script src="js/tinyscrollbar.js"></script> 
<script src="js/caroufredsel.js"></script> 
<script src="js/plugins.js"></script>
<script src="js/jquery.prettyPhoto.js"></script> 
<script src="js/jquery.isotope.min.js"></script> 
<script src="js/jquery.tweet.js"></script>
<script src="js/theme.js"></script>
<script src="custom/custom.js"></script>
<script src="js/jquery.datatable.js"></script>
<script src="js/bootstrap-datetimepicker.js"></script>
<script src="js/bsdate.js"></script>
<script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('.datepicker').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
            });

            $(document).ready(function() {
              $('#example').DataTable();
            });
        </script>
</body>
</html>
