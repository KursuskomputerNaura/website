<?php 
  $sql = $db->query("SELECT * FROM event ");
  while ($r = $sql->fetch_array()) {
echo "<div class='event'>
  <div class='portfolio'>
    <a href='gambar/$r[gambar]' class='portfolio'>
      <img src='gambar/$r[gambar]' alt='$r[judul]' width='215' height='132' />
    </a>
  </div>
  <div id='people_site'>
    <h3>$r[judul]</h3>
    $r[isi]
    <div id='button'>
      <a href='http://imi-event.esy.es'>Visit site</a>
    </div>
    </div>
  </div>";
  }
?>
