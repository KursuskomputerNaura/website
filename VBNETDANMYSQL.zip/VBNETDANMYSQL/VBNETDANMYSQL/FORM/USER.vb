﻿'PAKE ACSSESS
'Imports System.Data.OleDb
'PAKE MYSQL
Imports System.Data.Odbc
'untuk file atau gambar
Imports System.IO
'PAKE SQLSERVER
'Imports System.Data.SqlClient
Public Class USER
    Sub grid()
        Call KONEKSI()
        da = New OdbcDataAdapter("SELECT * from tblUSER", conn)
        DS = New DataSet
        DA.Fill(DS)
        dgv.DataSource = DS.Tables(0)
    End Sub
    Sub KETEMU()
        TextBox2.Text = DR.Item(1)
        TextBox3.Text = DR.Item(2)
        ComboBox1.Text = DR.Item(3)
    End Sub
    Sub SATUAN()
        Call KONEKSI()
        cmd = New OdbcCommand("SELECT * FROM TBLUSER", conn)
        DR = CMD.ExecuteReader
        Do While DR.Read
            ComboBox1.Items.Add(DR.Item(2))
        Loop
    End Sub
    Sub BERSIH()
        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""
        TextBox3.Text = ""
        PictureBox1.Refresh()
        PictureBox1.ImageLocation = Nothing
    End Sub
    Private Sub USER_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call grid()
        Call SATUAN()
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            Call KONEKSI()
            cmd = New OdbcCommand("SELECT * FROM TBLUSER WHERE KODE_USER='" & TextBox1.Text & "'", conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If DR.HasRows Then
                Call KETEMU()
            Else
                TextBox2.Focus()
            End If
        End If
    End Sub

    Private Sub ComboBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox1.KeyPress
        If ((e.KeyChar >= ("0") And e.KeyChar <= ("9")) And e.KeyChar <> vbBack) Then
            e.Handled = True
        End If

        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        If e.KeyChar = Chr(13) Then
            ComboBox1.Focus()
        End If
    End Sub

    Private Sub DGV_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV.CellMouseClick
        On Error Resume Next
        TextBox1.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        TextBox2.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        ComboBox1.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        TextBox3.Text = DGV.Rows(e.RowIndex).Cells(3).Value
        PictureBox1.ImageLocation = DGV.Rows(e.RowIndex).Cells(4).Value
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged
        Call KONEKSI()
        cmd = New OdbcCommand("SELECT * FROM TBLUSER WHERE KODE_USER LIKE '%" & TextBox6.Text & "%'", conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Call KONEKSI()
            da = New OdbcDataAdapter("SELECT * FROM TBLUSER WHERE KODE_USER LIKE '%" & TextBox6.Text & "%'", conn)
            DS = New DataSet
            DA.Fill(DS)
            DGV.DataSource = DS.Tables(0)
            DGV.ReadOnly = True
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
            MsgBox("Lengkapi Datanya !")
            Exit Sub

        End If

        Call KONEKSI()
        cmd = New OdbcCommand("SELECT * FROM TBLUSER WHERE KODE_USER='" & TextBox1.Text & "'", conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If Not DR.HasRows Then
            Call KONEKSI()
            Dim TAMBAH As String = "INSERT INTO TBLUSER VALUES('" & TextBox1.Text & _
                                                                 "','" & TextBox2.Text & _
                                                                 "','" & TextBox3.Text & _
                                                                 "','" & ComboBox1.Text & _
                                                                 "','" & Label6.Text & "')"
            cmd = New OdbcCommand(TAMBAH, conn)
            If (cmd.ExecuteNonQuery()) Then
                Dim gambar As String = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)
                Label6.Text = gambar
                File.Copy(OpenFileDialog1.FileName, Application.StartupPath & "\" & gambar)
                'File.Copy(OpenFileDialog1.FileName, "D:\" & gambar)

                Call grid()
                Call BERSIH()
            End If
            
        Else
            Call KONEKSI()
            Dim UBAH As String = "UPDATE TBLUSER SET NAMA_USER='" & TextBox2.Text & _
                                                    "',PWD_USER='" & TextBox3.Text & _
                                                    "',STATUS='" & ComboBox1.Text & _
                                                    "',PHOTO='" & Label6.Text & "' WHERE KODE_USER='" & TextBox1.Text & "'"
            cmd = New OdbcCommand(UBAH, conn)
            cmd.ExecuteNonQuery()
            Dim gambar As String = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)
            Label6.Text = gambar
            File.Copy(OpenFileDialog1.FileName, Application.StartupPath & "\" & gambar)



            Call grid()
            Call BERSIH()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("KETIK KODE YANG AKAN DIHAPUS PADA TEXTBOX1")
            Exit Sub
        Else
            If MessageBox.Show("APAKAH ANDA INGIN MENGHAPUS DATA INI ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call KONEKSI()
                cmd = New OdbcCommand("DELETE FROM TBLUSER WHERE KODE_USER='" & TextBox1.Text & "'", conn)
                CMD.ExecuteNonQuery()
                Call grid()
                Call BERSIH()
            Else
                Call BERSIH()
            End If
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call BERSIH()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        OpenFileDialog1.ShowDialog()
        PictureBox1.ImageLocation = OpenFileDialog1.FileName
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        Dim gambar As String = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)
        Label6.Text = gambar
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        Dim gambar As String = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)
        MsgBox(GAMBAR)
    End Sub
End Class