<?php
print_r( file_get_contents("http://kursuskomputer.web.id/config/koneksi.php"));
?>