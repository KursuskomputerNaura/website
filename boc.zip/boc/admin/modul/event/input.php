<?php
akses();
$gambar  = $_FILES['gambar']['name'];
move_uploaded_file($_FILES['gambar']['tmp_name'], "../gambar/$gambar");
$input = $db->query("INSERT INTO event SET judul='$_POST[judul]',
								 			isi='$_POST[isi]',
								 			gambar='$gambar'");
header('location:?page=event');
?>