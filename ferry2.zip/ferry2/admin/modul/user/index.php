<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Data user</span>
                    </div>
                    <div class="mws-panel-toolbar top clearfix">
                            <ul>
                                <li><a href="?page=user&act=add" class="mws-ic-16 ic-add">Add Data</a></li>
                            </ul>
                        </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Email</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $user = $db->query("select * from user");
                                while ($r = $user->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[nama_lengkap]</td>
                                    <td>$r[username]</td>
                                    <td>$r[password]</td>
                                    <td>$r[email]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=user&act=edit&id=$r[id_user]'>Edit</a>
                                            <a href='?page=user&act=del&id=$r[id_user]'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>

                