<?php 
$edit = $db->query("select * from faq where id_faq='$_GET[id]'");
$r = $edit->fetch_array();
?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Add faq</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=faq&act=update' method="post">
                        <input type='hidden' name="id" value="<?php echo $r['id_faq']; ?>">
                            <div class='mws-form-inline'>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Nama Lengkap</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="nama_lengkap"  class='mws-textinput' value="<?php echo $r['nama_lengkap']; ?>">
                                    </div>
                                </div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Email</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="email" class='mws-textinput' value="<?php echo $r['email']; ?>">
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Pesan</label>
                                    <div class='mws-form-item'>
                                        <?php echo $r['pesan']; ?>
                                    </div>
                                </div>

                                <div class="mws-form-row">
                                    <label class="mws-form-label">Balasan</label>
                                    <div class="mws-form-item">
                                        <textarea rows="" cols="" class="large" id="elrte" name="balas"><?php echo $r['balas']; ?></textarea>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Email</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="email" class='mws-textinput' value="<?php echo $r['email']; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=faq' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
                </div>