<?php 
ob_start();
include "config/koneksi.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>IMI | Ikatan Motor Indonesia</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/about_us - style.css" rel="stylesheet" type="text/css" />
<link href="css/contact - style.css" rel="stylesheet" type="text/css" />
<link href="css/portfolio - style.css" rel="stylesheet" type="text/css" />
<link href="css/services - style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<script type="text/javascript">
  $(function() {
    $('.portfolio').lightBox();
  });
  </script>

</head>

<div class="main">
<div class="top_list"></div>
<div class="header-bg"></div>
<div class="header">
 
  <div class="logo"></div>
</div>

 <div class="menu">
   <ul id="nav">
       <li class="e"><a href="index.php">Home</a></li>
       <li class="a"><a href="?page=about">About</a></li>
       <li class="b"><a href="?page=news">News</a></li>
       <li class="c"><a href="?page=event">Event</a></li>
       <li class="d"><a href="?page=faq">FAQ</a></li>  
       <li class="d"><a href="?page=contact">Contact</a></li>  
       <div class="clear"></div>
  </ul>
 </div>

  
<?php 
$page = isset($_GET['page']) ? $_GET['page']:'';
if ($page) {
  include "modul/$page.php";
}else{
  include "modul/home.php";
}
?>
                      
<div class="footer">

    
<div class="footer-bg"></div>
<div id="copyright"> Copyright &copy;.  All Right Reserved.</div>
    <div id="nav-footer">
       <!-- <a href="index.php">Home</a> &nbsp;&nbsp;
       <a href="?page=aboutus">About</a> &nbsp;&nbsp;
       <a href="?page=event">Blog</a> &nbsp;&nbsp;
       <a href="?page=registrasi">Event</a> &nbsp;&nbsp;
       <a href="?page=contact">Contact</a></div></div> -->
</div>
</body>
</html>
