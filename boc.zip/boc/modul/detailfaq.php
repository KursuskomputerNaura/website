
<?php 
  $sql = $db->query("SELECT * FROM faq WHERE id_faq='$_GET[id]'");
  while ($r = $sql->fetch_array()) {
echo "<div class='content'>
<h3>$r[nama_lengkap]</h3>
<p>Pertanyaan : $r[pesan]</p>
<hr>
<p>Jawaban : $r[balas]</p>
       <a href='?page=faq'>Kembali</a>
</div>";
  }
?>
