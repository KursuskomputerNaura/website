<div class="content"><h3>Selamat Datang di Website Ikatan Motor Indonesia Cabang Banten</h3>
Di era sekarang ini, perkembangan teknologi sudah mengalami kemajuan yang sangat signifikan, terutama di bidang komputer, khususnya web desain. Bisa di lihat dari banyaknya toko-toko online yang ada di dunia maya, yang ingin memperluas pemasaran dan memperkenalkan produknya secara lebih luas, serta banyaknya perusahaan - perusahaan atau instansi - instansi yang ingin meningkatkan daya saing dan mempermudah komunikasi dengan klien mereka. Oleh karena itu webnation.com hadir untuk memberikan solusi dan membantu anda dalam mewujudkan mimpi mempunyai website yang anda inginkan.</div>

<div class="box_banner-1">
  <div id="banner-1">
     <div id="inset_banner-1">
        <img src="img/icon_monitor.png" width="103" height="97" style="margin-top:60px" /></div></div>
        <div id="A">What we do</div>
         Kami membuat website yang elegan dan fungsional, sesuai dengan kebutuhan dan mimpi anda agar mudah digunakan oleh para pengunjung sehingga mereka ingin kembali mengunjungi website anda.</div>
     
<div class="box_banner-2">
  <div id="banner-2">
    <div id="inset_banner-2">
       <img src="img/icon_services.png" width="103" height="97" style="margin-top:60px" /></div></div>
       <div id="B">Our Services</div>
         Kami akan membuatkan website yang mudah digunakan oleh pengunjung website anda dan anda sendiri, dengan menggunakan admin navigasi kontrol, anda bisa dengan mudah mengupdate, menghapus, menambah item yang ada di website anda, bahkan untuk anda yang awam sekalipun.</div>

<div class="box_banner-3">
  <div id="banner-3">
    <div id="inset_banner-3">
       <img src="img/icon_support.png" width="103" height="97" style="margin-top:60px" /></div></div>
       <div id="C">Our Support</div>
        Kami  menggunakan aplikasi Adobe Photoshop, Adobe Illustrator, Adobe Dreamweaver, HTML, CSS/3, PHP, MYSQL dan secangkir kopi.</div>