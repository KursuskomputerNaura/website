﻿Imports System.Data.Odbc
Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Module Module1
    Public conn As New OdbcConnection
    Public da As New OdbcDataAdapter
    Public ds As New DataSet
    Public cmd As New OdbcCommand
    Public dr As OdbcDataReader

    Public cryRpt As New ReportDocument
    Public crtableLogoninfos As New TableLogOnInfos
    Public crtableLogoninfo As New TableLogOnInfo
    Public crConnectionInfo As New ConnectionInfo
    Public CrTables As Tables

    Public Sub seting_laporan()
        With crConnectionInfo
            .ServerName = FrmKoneksi.TextBox2.Text
            .DatabaseName = FrmKoneksi.TextBox2.Text
            .UserID = FrmKoneksi.TextBox2.Text
            .Password = FrmKoneksi.TextBox2.Text
        End With

        CrTables = cryRpt.Database.Tables
        For Each CrTable In CrTables
            crtableLogoninfo = CrTable.LogOnInfo
            crtableLogoninfo.ConnectionInfo = crConnectionInfo
            CrTable.ApplyLogOnInfo(crtableLogoninfo)
        Next
    End Sub

    Public Sub koneksi()
        'conn = New OdbcConnection("{DRIVER=MYSQL ODBC 3.51 DRIVER};SERVER=" & FrmKoneksi.TextBox1.Text & ";USERID=" & FrmKoneksi.TextBox2.Text & ";PASSWORD=" & FrmKoneksi.TextBox3.Text & ";DATABASE=" & FrmKoneksi.ComboBox1.Text & "")
        conn = New OdbcConnection("Driver={MYSQL ODBC 3.51 DRIVER};server=127.0.0.1;DATABASE=APLIKASIPENJUALAN;uid=root;password=;port=3306;")
        conn.Open()
        If conn.State <> ConnectionState.Open Then
            MsgBox("TIDAK BISA TERKONEKSI KESERVER")
            FrmKoneksi.Show()

        End If
    End Sub
    
End Module
