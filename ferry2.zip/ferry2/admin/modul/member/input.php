<?php 
akses();
$db->query("INSERT INTO member SET nama_lengkap='$_POST[nama_lengkap]',
								   tempat_lahir='$_POST[tempat_lahir]',
								   tanggal_lahir='$_POST[tanggal_lahir]',
								   agama='$_POST[agama]',
								   jenis_kelamin='$_POST[jenis_kelamin]',
								   email='$_POST[email]',
								   password='".md5($_POST[password])."',
								   telepon='$_POST[telepon]',
								   aktif='$_POST[aktif]'");
header('location:?page=member');
?>