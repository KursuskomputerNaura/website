<?php
akses(); 
$db->query("delete from event where id_event='$_GET[id]'");
header('location:?page=event');
?>