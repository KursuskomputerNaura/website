
<?php 
  $sql = $db->query("SELECT * FROM artikel WHERE id_artikel='$_GET[id]'");
  while ($r = $sql->fetch_array()) {
echo "<div class='content'>
<h3>$r[judul]</h3>
   <img src='gambar/$r[gambar]' alt='$r[judul]'/>
       <p>$r[isi]</p>
       <a href='?page=blog'>Kembali</a>
</div>";
  }
?>
