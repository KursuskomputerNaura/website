<div class="container">
	<form name="myForm" method="post" action="?page=aksidaftar">
	<legend>Form Pendafataran Member</legend>

	<div class="control-group">
		<label for="">Nama Lengkap</label>
		<input type="text" class="form-control" name="nama_lengkap">
	</div>

	<div class="control-group">
		<label for="">Tempat Lahir</label>
		<input type="text" class="form-control" name="tempat_lahir">
	</div>
	
	<div class="control-group">
		<label for="">Tanggal Lahir</label>
		<input type="text" class="form-control datepicker" name="tanggal_lahir">
	</div>
	
	<div class="control-group">
		<label for="">Agama</label>
		<select name="agama" class="form-control">
			<option>Pilih Agama</option>
			<option value="Islam">Islam</option>
			<option value="Khatolik">Khatolik</option>
			<option value="Protestan">Protestan</option>
			<option value="Hindu">Hindu</option>
			<option value="Budha">Budha</option>
		</select>
	</div>

	<div class="control-group">
		<label for="">Jenis Kelamin</label>
		<select name="jenis_kelamin" class="form-control">
			<option>Pilih Gender</option>
			<option value="Laki-Laki">Laki-Laki</option>
			<option value="Perempuan">Perempuan</option>
		</select>
	</div>

	<div class="control-group">
		<label for="">Email</label>
		<input type="text" class="form-control" name="email" >
	</div>

	<div class="control-group">
		<label for="">Password</label>
		<input type="password" class="form-control" name="password" >
	</div>

	<div class="control-group">
		<label for="">Telepon</label>
		<input type="number" class="form-control" name="telepon">
	</div>

	<button type="submit" class="btn btn-primary">Submit</button>
	<a href="index.php" class="btn btn-warning" id="kembali">Kembali</a>
</form>
</div>

