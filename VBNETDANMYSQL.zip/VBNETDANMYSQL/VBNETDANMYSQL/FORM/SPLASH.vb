﻿Public Class SPLASH
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.Opacity = 0.8
        PGB.Value += 40
        If PGB.Value = 200 Then
            Timer1.Dispose()
            Me.Visible = False

            FRM_MAIN.Show()

        End If
        Label2.Left = Label2.Left + 1
        If Label2.Width <= 0 Then
            Label2.Left = Label2.Left - 1
        End If
    End Sub
End Class