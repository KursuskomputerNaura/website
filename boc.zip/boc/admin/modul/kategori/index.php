<?php akses(); ?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Table with Toolbar</span>
                    </div>
                    <div class='mws-panel-toolbar '>
                        <div class='btn-toolbar'>
                            <div class='btn-group'>
                                <a href='?page=kategori&act=add' class='mws-button'>Add Kategori</a>
                            </div>
                        </div>
                    </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kategori</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $artikel = $db->query("select * from kategori");
                                while ($r = $artikel->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[kategori]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=kategori&act=edit&id=$r[id_kategori]' class='mws-btn btn-small'>Edit</a>
                                            <a href='?page=kategori&act=del&id=$r[id_kategori]' class='mws-btn btn-small'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>
                