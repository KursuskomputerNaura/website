﻿Imports System.Data.Odbc
Public Class GantiPassword

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'jika tombol proses di klik maka validasi inputan supaya tidak kosong
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Data tidak Lengkap")
            Exit Sub
        Else
            'panggil koneksi
            Call koneksi()
            'cek database username yang sama pada label2 menu utama
            cmd = New OdbcCommand("select * from tbluser where nama_user='" & FRM_MAIN.Label2.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                'kalo password yang lagi login sama dengan didatabase
                If TextBox1.Text = dr.Item("password") Then
                    Call koneksi()
                    cmd = New OdbcCommand("update tbluser set password='" & TextBox2.Text & "'", conn)
                    If cmd.ExecuteNonQuery() Then
                        MsgBox("Password Berhasil Diganti")
                    End If
                Else
                    MsgBox("anda tidak berhak mengganti password")
                    Exit Sub
                End If
            Else
                MsgBox("User Tidak Terdaftar")

            End If
            
        End If
    End Sub
End Class