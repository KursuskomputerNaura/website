<?php 
akses();
?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Add member</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=member&act=input' method="post">
                            <div class='mws-form-inline'>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Nama Lengkap</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="nama_lengkap"  class='mws-textinput'>
                                    </div>
                                </div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Tempat Lahir</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="tempat_lahir" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Tanggal Lahir</label>
                                    <div class='mws-form-item'>
                                        <input type='date' name="tanggal_lahir" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Agama</label>
                                    <div class='mws-form-item'>
                                        <select name="agama" class="form-control">
                                            <option>Pilih Agama</option>
                                            <option value="Islam">Islam</option>
                                            <option value="Khatolik">Khatolik</option>
                                            <option value="Protestan">Protestan</option>
                                            <option value="Hindu">Hindu</option>
                                            <option value="Budha">Budha</option>
                                        </select>
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Jenis Kelamin</label>
                                    <div class='mws-form-item'>
                                        <select name="jenis_kelamin" class="form-control">
                                            <option>Pilih Gender</option>
                                            <option value="Laki-Laki">Laki-Laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                        </select>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Email</label>
                                    <div class='mws-form-item'>
                                        <input type='email' name="email" class='mws-textinput'>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Password</label>
                                    <div class='mws-form-item'>
                                        <input type='password' name="password" class='mws-textinput'>
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Telepon</label>
                                    <div class='mws-form-item'>
                                        <input type='number' name="telepon" class='mws-textinput'>
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Aktif</label>
                                    <div class='mws-form-item'>
                                        <select name="jenis_kelamin" class="form-control">
                                            <option>Pilih Status</option>
                                            <option value="Y">Aktif</option>
                                            <option value="N">Tidak Aktif</option>
                                        </select>
                                    </div>
                                </div>


                            </div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=member' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
                </div>