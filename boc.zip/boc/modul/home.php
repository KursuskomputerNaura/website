<?php 
  $sql = $db->query("SELECT * FROM halaman where id_halaman=1");
  while ($r = $sql->fetch_array()) {
echo "<div class='content'>
    <h3>$r[judul]</h3>
  <img src='gambar/$r[gambar]' alt='$r[judul]$r[judul]'>
  <p>$r[isi]</p>
</div>";
  }
?>
