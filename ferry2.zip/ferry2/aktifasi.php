<?php 
include 'config/koneksi.php';
$aktif = $db->query("UPDATE member SET aktif='Y' WHERE email='$_GET[email]'");
echo "<script>
           alert('Pendaftaran Berhasil');
           window.location='../index.php';
	</script>";
?>