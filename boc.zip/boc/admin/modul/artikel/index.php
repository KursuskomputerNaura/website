<?php 
 akses();
?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Data Artikel</span>
                    </div>
                    <div class='mws-panel-toolbar '>
                        <div class='btn-toolbar'>
                            <div class='btn-group'>
                                <a href='?page=artikel&act=add' class='btn'>Add artikel</a>
                            </div>
                        </div>
                    </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Tanggal</th>
                                    <th>author</th>
                                    <th>Kategori</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $artikel = $db->query("select * from view_artikel");
                                while ($r = $artikel->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[judul]</td>
                                    <td>$r[tanggal]</td>
                                    <td>$r[nama_lengkap]</td>
                                    <td>$r[kategori]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=artikel&act=edit&id=$r[id_artikel]'>Edit</a>
                                            <a href='?page=artikel&act=del&id=$r[id_artikel]'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>
                