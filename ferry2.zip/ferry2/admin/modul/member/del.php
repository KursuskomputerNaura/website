<?php 
akses();
$db->query("delete from member where id_member='$_GET[id]'");
header('location:?page=member');
?>