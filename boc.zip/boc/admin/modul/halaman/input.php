<?php
akses();
$id_user = $_SESSION['id'];
$gambar  = $_FILES['gambar']['name'];
move_uploaded_file($_FILES['gambar']['tmp_name'], "../gambar/$gambar");
$input = $db->query("INSERT INTO halaman SET  judul='$_POST[judul]',
								 			  isi='$_POST[isi]',
								              gambar='$gambar',
								              id_user='$id_user'");

header('location:?page=halaman');
?>