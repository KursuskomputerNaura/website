﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class FormLaporan


   

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CR.ReportSource = Nothing
        cryRpt.Load("REPORT/Laporan Barang.rpt")
        Call seting_laporan()
        CR.Refresh()
        CR.ReportSource = cryRpt
        CR.RefreshReport()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Try
            CR.Refresh()
            CR.SelectionFormula = "({tblpenjualan.tanggal}) in  Date ('" & DtpHarian.Text & "')"
            CR.ReportSource = "REPORT/Laporan Penjualan Harian2.rpt"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub DtpHarian_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DtpHarian.ValueChanged
        DtpHarian.Format = DateTimePickerFormat.Custom
        DtpHarian.CustomFormat = "yyyy-MM-dd"
    End Sub
End Class