﻿Imports System.Data.Odbc
Public Class FRM_MAIN
    Sub hakakses()

    End Sub
    'konfirmasi menutup form utama
    Private Sub MENU_UTAMA_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
        If MsgBox("Yakin mau keluar?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo) <> Windows.Forms.DialogResult.Yes Then
            e.Cancel = True
        End If
    End Sub



    Private Sub MENU_UTAMA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TabControl1.Enabled = False
        LOGIN.MdiParent = Me
        LOGIN.Show()
        KOLOM1.Text = Format(Now, "yyyy-MM-dd")
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        KOLOM2.Text = Format(Now, "H:m:s")
        Timer1.Start()
    End Sub



    Private Sub btnbarang_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnbarang.Click
        BARANG.MdiParent = Me
        BARANG.Show()
    End Sub

    Private Sub btnpenjualan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpenjualan.Click
        PENJUALAN.MdiParent = Me
        PENJUALAN.Show()
    End Sub


    Private Sub btnreturjual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreturjual.Click
        ReturJual.MdiParent = Me
        ReturJual.Show()
    End Sub


    Private Sub BTNHAKAKSES_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNHAKAKSES.Click

    End Sub

    Private Sub BTNLAPMASTER_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNLAPMASTER.Click
        FormLaporan.Show()
    End Sub


    Private Sub btnuser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnuser.Click
        USER.Show()
    End Sub

    Private Sub btngantipassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngantipassword.Click
        GantiPassword.Show()
    End Sub

    Private Sub btnkonfigurasiserver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnkonfigurasiserver.Click
        FrmKoneksi.Show()
    End Sub
End Class