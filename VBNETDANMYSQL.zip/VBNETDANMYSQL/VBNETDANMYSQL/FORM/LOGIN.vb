﻿Imports System.Data.Odbc
Public Class LOGIN
    Sub BERSIH()
        TextBox1.Clear()
        TextBox1.Clear()
    End Sub
    

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("LENGKAPI DATA ANDA !")
            Exit Sub
        End If

        Call KONEKSI()
        cmd = New OdbcCommand("SELECT * FROM TBLUSER WHERE NAMA_USER='" & Trim(TextBox1.Text) & "' AND PWD_USER='" & Trim(TextBox2.Text) & "'", conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            MsgBox("ANDA BERHASIL LOGIN", MsgBoxStyle.Information, "NAURAPOS")
            Me.Visible = False
            Call BERSIH()
            FRM_MAIN.Show()
            FRM_MAIN.TabControl1.Enabled = True
            FRM_MAIN.Panel1.Text = dr.Item(0)
            FRM_MAIN.Panel2.Text = dr.Item(1)
            FRM_MAIN.Panel3.Text = dr.Item(2)
            'MENU_UTAMA.PictureBox1.ImageLocation = dr.Item(4)
            If FRM_MAIN.Label3.Text = "USER" Then
                FRM_MAIN.btnbarang.Visible = False
            End If
        Else
            MsgBox("ANDA GAGAL LOGIN", MsgBoxStyle.Critical, "NAURAPOS")
            Me.Visible = True

        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End
    End Sub


    Private Sub TextBox1_KeyPress1(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress1(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

End Class