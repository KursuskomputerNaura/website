<?php
akses();
$tanggal = date('Y-m-d');
$id_user = $_SESSION['id'];
$gambar  = $_FILES['gambar']['name'];

if (empty($gambar)) {
	$input = $db->query("UPDATE halaman SET judul='$_POST[judul]',
								 				 isi='$_POST[isi]',
								 				 id_user='$id_user'
								 				 WHERE id_halaman='$_POST[id]'");
}else{
	//untuk menghapus gambar sebelumnya
	$edit = $db->query("select * from halaman where id_halaman='$_POST[id]'");
	$r = $edit->fetch_array();
	$file = "../gambar/$r[gambar]";
	unlink($file);
	//untuk upload gambar baru
	move_uploaded_file($_FILES['gambar']['tmp_name'], "../gambar/$gambar");
	$input = $db->query("UPDATE halaman SET judul='$_POST[judul]',
								 isi='$_POST[isi]',
								 gambar='$gambar',
								 id_user='$id_user'
								 WHERE id_halaman='$_POST[id]'");
}


header('location:?page=halaman');
?>