<div class="container">
<?php
/*include '../config/koneksi.php';*/
include '../config/apisms.php';
//validasi
if (trim($_POST['nama_lengkap']) == '') {
	$error[] = '- Nama harus diisi';
}
if (trim($_POST['tempat_lahir']) == '') {
	$error[] = '- tempat lahir harus diisi';
}
if (trim($_POST['tanggal_lahir']) == '') {
	$error[] = '- tanggal lahir harus diisi';
}
if (trim($_POST['agama']) == '') {
	$error[] = '- agama harus diisi';
}
if (trim($_POST['jenis_kelamin']) == '') {
	$error[] = '- jenis kelamin  harus diisi';
}
if (trim($_POST['email']) == '') {
	$error[] = '- Tempat Lahir harus diisi';
}
if (trim($_POST['password']) == '') {
	$error[] = '- password Lahir harus diisi';
}
if (trim($_POST['telepon']) == '') {
	$error[] = '- telepon Lahir harus diisi';
}
//dan seterusnya
 
if (isset($error)) {
	echo '<b>Error</b>: <br />'.implode('<br />', $error);
} else {
	/*
	Input Kedatabase
	*/
	$insert = $db->query("INSERT INTO member SET nama_lengkap='$_POST[nama_lengkap]',
		                                         tempat_lahir='$_POST[tempat_lahir]',
		                                         tanggal_lahir='$_POST[tanggal_lahir]',
		                                         agama='$_POST[agama]',
		                                         jenis_kelamin='$_POST[jenis_kelamin]',
		                                         email='$_POST[email]',
		                                         password='$_POST[password]',
		                                         telepon='$_POST[telepon]'");
	/*
		setelah berhasil input kedatabase kirim email ke calon  peserta

	*/

	$to = $_POST['email'];
	$no_daftar = mysqli_insert_id($db);
	$subject = "Konfirmasi Pendaftaran Racing Banten";
	$body = "Data anda sudah kami terima,untuk di proses, <a href='http://localhost/ferry2/aktifasi.php?email=$to'>klik disini</a> untuk memverifikasi data anda No Daftar Anda <b>$no_daftar</b>";
	$headers = "From: admin@localhost \r\n";
    $headers.="Reply-to: admin@localhost \r\n";
    $headers.='MIME-Version: 1.0'."\r\n";
    $headers.='Content-type: text/html; charset=iso-8859-1'."\r\n";
    mail($to, $subject, $body,$headers);
/*
Kirim sms ke admin web
*/
//setingan ini ada di menu API Key zenziva anda
$userkey='wgpziu';
$passkey='12345';

KirimSMS($_POST['telepon'],$body,$userkey,$passkey);

	echo "<script>
           alert('Data berhasil dikirim,selanjutnya cek email untuk info selanjutnya');
           window.location='../index.php';
	</script>";
}
die();
?>
</div>