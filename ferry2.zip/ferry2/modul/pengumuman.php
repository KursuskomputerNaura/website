<div class="container">
	<?php 
	$sql = $db->query("select * from pengumuman order by id_pengumuman desc limit 1");
	while ($r=$sql->fetch_array()) {
		echo "<img src='gambar/$r[gambar]'><h3>$r[judul]</h3><p>$r[isi]</p>";
	}
	 ?>	

	 
	 
<h3>Data Peserta yang akan mengikuti Banten Racing</h3>
	<table id="example" class="table table-boredered display">
		<thead>
			<tr>
				<th>Nama Lengkap</th>
				<th>Jenis Kelamin</th>
				<th>Email</th>
				<th>Telepon</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				$sql = $db->query("SELECT * FROM member where lulus='Y' AND konfirmasi='Y'");
				while ($r = $sql->fetch_array()) {
			echo "<tr>
				<td>$r[nama_lengkap]</td>
				<td>$r[jenis_kelamin]</td>
				<td>$r[email]</td>
				<td>$r[telepon]</td>
			</tr>";
				}
			 ?>
		</tbody>
	</table>
	<hr>
	<a href="index.php" class="btn btn-warning" id="kembali">Kembali</a>
</div>