<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Data faq</span>
                    </div>
                    <div class="mws-panel-toolbar top clearfix">
                            
                        </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Email</th>
                                    <th>Pesan</th>
                                    <th>Nama Balas</th>
                                    <th>Balas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $faq = $db->query("select * from faq");
                                while ($r = $faq->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[nama_lengkap]</td>
                                    <td>$r[email]</td>
                                    <td>$r[pesan]</td>
                                    <td>$r[nama_balas]</td>
                                    <td>$r[balas]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=faq&act=edit&id=$r[id_faq]'>Edit</a>
                                            <a href='?page=faq&act=del&id=$r[id_faq]'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>

                