<?php
akses();
$namauser = $_SESSION['namauser'];

$db->query("UPDATE faq SET nama_lengkap='$_POST[nama_lengkap]',
							email='$_POST[email]',
							username='$namauser',
							balas='$_POST[balas]'
								 WHERE id_faq='$_POST[id]'");
header('location:?page=faq');
?>