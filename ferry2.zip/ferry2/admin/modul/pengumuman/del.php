<?php 
akses();
$db->query("delete from pengumuman where id_pengumuman='$_GET[id]'");
header('location:?page=pengumuman');
?>