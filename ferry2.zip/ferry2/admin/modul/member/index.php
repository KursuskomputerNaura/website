<?php 
akses();
?>
<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Data Pendaftar</span>
                    </div>
                    <div class="mws-panel-toolbar top clearfix">
                            <ul>
                                <li><a href="?page=member&act=add" class="mws-ic-16 ic-add">Daftar Baru</a></li>
                            </ul>
                        </div>
                    <div class='mws-panel-body no-padding'>
                    <form method="post" action="?page=member&act=lulus">
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Bukti Bayar</th>
                                    <th>Email</th>
                                    <th>Telepon</th>
                                    <th>Aktif</th>
                                    <th>Lulus</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $i=1; 
                                $member = $db->query("select * from member");
                                while ($r = $member->fetch_array()) {
                                    echo " 
                                    <input value='$r[id_member]' type='hidden' name='id[$i]'>
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[nama_lengkap]</td>
                    <td><img src='../gambar/$r[bukti_bayar]' width='150'></td>
                                    <td>$r[email]</td>
                                    <td>$r[telepon]</td>
                                    <td>$r[aktif]</td>
                                    <td>$r[lulus]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=member&act=edit&id=$r[id_member]'>Edit</a>
                                            <a href='?page=member&act=del&id=$r[id_member]'>Hapus</a>
                                        </span>
                                    </td>
                                </tr>";

                                $i++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                       <!--  <input type="Submit" class="mws-btn btn-success" value="Lakukan Perubahan"> -->
                        </form>
                        </div>
                    </div>      
                </div>

                <!-- <td>
                                        <select name='lulus[$i]'>
                                        <option value='N'>N</option>
                                        <option value='Y' "; if($r['lulus']=='Y'){echo "selected";}echo">Y</option>
                                        
                                    </select>
                                    </td> -->

                