﻿Imports System.Data.Odbc
'Imports CrystalDecisions.CrystalReports.Engine
'Imports CrystalDecisions.Shared
Public Class PENJUALAN
    'Dim myReport As New ReportDocument()
    Sub FAKTUR()
        Call koneksi()
        cmd = New OdbcCommand("select * from tblpenjualan where faktur in(select max(faktur) from tblpenjualan)", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            LBLFAKTUR.Text = Format(Now, "yyMMdd") + "0001"
        Else
            If Microsoft.VisualBasic.Left(dr.Item("faktur"), 6) = Format(Now, "yyMMdd") Then
                LBLFAKTUR.Text = dr.Item("faktur") + 1
            Else
                LBLFAKTUR.Text = Format(Now, "yyMMdd") + "0001"
            End If
        End If
    End Sub
    Sub HitungBarang()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DGV.RowCount - 1
            hitung = hitung + DGV.Rows(baris).Cells(3).Value
            LBLJUMLAHBARANG.Text = hitung
        Next
    End Sub

    Sub HitungHarga()
        Dim hitung As Decimal = 0
        For baris As Integer = 0 To DGV.RowCount - 1
            hitung = hitung + DGV.Rows(baris).Cells(6).Value
            LBLTOTAL.Text = hitung
        Next
    End Sub
    Sub Bersihkan()
        ComboBox1.Text = ""
        LBLJUMLAHBARANG.Text = ""
        LBLTOTAL.Text = ""
        TXTDIBAYAR.Text = ""
        TXTDISKON.Text = ""
        LBLKEMBALI.Text = ""
        TXTTERBILANG.Text = ""
        DGV.Columns.Clear()
        Call buatkolom()
    End Sub


    Sub buatkolom()
        DGV.Columns.Add("KODEBARANG", "KODE BARANG")
        DGV.Columns.Add("NAMABARANG", "NAMA BARANG")
        DGV.Columns.Add("HARGA", "HARGA")
        DGV.Columns.Add("JUMLAH", "JUMLAH")
        DGV.Columns.Add("SUBTOTAL", "SUBTOTAL")
        DGV.Columns.Add("diskon_peritem", "Diskon Item")
        DGV.Columns.Add("subtotsldiskon", "Harga Diskon")
        DGV.Columns("HARGA").ReadOnly = True
        DGV.Columns("SUBTOTAL").ReadOnly = True
        DGV.Columns("subtotsldiskon").ReadOnly = True
        DGV.Columns("subtotsldiskon").Width = 200
        DGV.Columns("NAMABARANG").Width = 200
        DGV.Columns("KODEBARANG").Width = 200
        DGV.Columns("HARGA").DefaultCellStyle.Format = "###,###,###"
        DGV.Columns("SUBTOTAL").DefaultCellStyle.Format = "###,###,###"
        DGV.Columns("subtotsldiskon").DefaultCellStyle.Format = "###,###,###"
        DGV.Columns("HARGA").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DGV.Columns("SUBTOTAL").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DGV.Columns("subtotsldiskon").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DGV.Columns("diskon_peritem").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DGV.Columns("JUMLAH").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    End Sub
    Sub TAMPILCUSTOMER()
        Call koneksi()
        cmd = New OdbcCommand("SELECT * FROM TBLCUSTOMER ORDER BY KODE_CUSTOMER ASC", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            'supaya tampil autocomplete dropdown
            ComboBox1.AutoCompleteCustomSource.Add(dr.Item(1) & Space(2) & dr.Item(2) & Space(2) & dr.Item(0))
            On Error Resume Next
            DGV.Focus()


        Loop
    End Sub

    Private Sub PENJUALAN_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'saat form penjualan tampil maka tampilkan sub sub diatas yang sudah kita buat
        Call FAKTUR()
        Call TAMPILCUSTOMER()
        LBLTANGGAL.Text = Format(Now, "yyyy-MM-dd")
        Call buatkolom()
    End Sub




    Private Sub DGV_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellEndEdit
        If DGV.Rows(e.RowIndex).Cells(0).Value = "" Then
            MsgBox("KETIK DULU KODENYA")
            Exit Sub
        End If
        If e.ColumnIndex = 0 Then
            Call koneksi()
            cmd = New OdbcCommand("SELECT * FROM TBLBARANG WHERE KODE_BARANG='" & DGV.Rows(e.RowIndex).Cells(0).Value & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then

                'jika stok tidak sedang kosong
                If dr.Item(5) <> 0 Then
                    DGV.Rows(e.RowIndex).Cells(1).Value = dr.Item(1)
                    DGV.Rows(e.RowIndex).Cells(2).Value = dr.Item(4)
                    DGV.Rows(e.RowIndex).Cells(3).Value = 1
                    DGV.Rows(e.RowIndex).Cells(4).Value = DGV.Rows(e.RowIndex).Cells(2).Value * DGV.Rows(e.RowIndex).Cells(3).Value
                    DGV.Rows(e.RowIndex).Cells(5).Value = 0
                    DGV.Rows(e.RowIndex).Cells(6).Value = Val(DGV.Rows(e.RowIndex).Cells(4).Value) - (Val(DGV.Rows(e.RowIndex).Cells(4).Value * (Val(DGV.Rows(e.RowIndex).Cells(5).Value)) / 100))
                    DGV.CurrentCell = DGV(0, DGV.CurrentCell.RowIndex)
                    Call HitungBarang()
                    Call HitungHarga()
                    TXTTERBILANG.Text = Terbilang(Val(LBLTOTAL.Text)) & "Rupiah"

                    'untuk scanner barcode barang yang sama maka jumlah ditambah 1
                    For i As Integer = 0 To DGV.RowCount - 1
                        For j As Integer = i + 1 To DGV.RowCount - 1
                            If DGV.Rows(j).Cells(0).Value = DGV.Rows(i).Cells(0).Value Then
                                'MsgBox("Kode ini sudah dientri")
                                DGV.Rows.RemoveAt(DGV.CurrentCell.RowIndex)
                                DGV.Rows(i).Cells(3).Value = DGV.Rows(i).Cells(3).Value + 1
                                DGV.Rows(i).Cells(4).Value = DGV.Rows(i).Cells(2).Value * DGV.Rows(i).Cells(3).Value
                                DGV.Rows(i).Cells(6).Value = Val(DGV.Rows(i).Cells(4).Value) - (Val(DGV.Rows(i).Cells(4).Value * (Val(DGV.Rows(i).Cells(5).Value)) / 100))
                                SendKeys.Send("{down}")
                                Call HitungBarang()
                                Call HitungHarga()
                                TXTTERBILANG.Text = Terbilang(Val(LBLTOTAL.Text)) & "Rupiah"
                                Exit Sub

                            End If
                        Next
                    Next




                Else
                    MsgBox("BARANG KOSONG,STOK HANYA ADA " & dr.Item(5), MsgBoxStyle.Information, "INFORMASI STOK")
                    DGV.Focus()
                    SendKeys.Send("{up}")
                    Call HitungBarang()
                    Call HitungHarga()


                End If
            Else
                MsgBox("KODE BARANG BELUM TERDAFTAR")
                DGV.Focus()
                Exit Sub
            End If
            Call HitungBarang()
            Call HitungHarga()
        End If

        If e.ColumnIndex = 3 Then
            Call koneksi()
            cmd = New OdbcCommand("select * from tblbarang where kode_barang='" & DGV.Rows(e.RowIndex).Cells(0).Value & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If DGV.Rows(e.RowIndex).Cells(3).Value > dr.Item("stok") Then
                MsgBox("Jumlah barang hanya ada " & dr.Item("stok") & "")
                DGV.Rows(e.RowIndex).Cells(3).Value = 0
                SendKeys.Send("{up}")
                Exit Sub
            End If
            Try
                DGV.Rows(e.RowIndex).Cells(4).Value = DGV.Rows(e.RowIndex).Cells(2).Value * DGV.Rows(e.RowIndex).Cells(3).Value
                DGV.Rows(e.RowIndex).Cells(6).Value = Val(DGV.Rows(e.RowIndex).Cells(4).Value) - (Val(DGV.Rows(e.RowIndex).Cells(4).Value * (Val(DGV.Rows(e.RowIndex).Cells(5).Value)) / 100))
                Call HitungBarang()
                Call HitungHarga()
                TXTTERBILANG.Text = Terbilang(Val(LBLTOTAL.Text)) & "Rupiah"
            Catch ex As Exception
                MsgBox(ex.Message)
                DGV.Rows(e.RowIndex).Cells(3).Value = 0
                SendKeys.Send("{up}")
            End Try

        End If
        If e.ColumnIndex = 5 Then
            Try
                DGV.Rows(e.RowIndex).Cells(6).Value = Val(DGV.Rows(e.RowIndex).Cells(4).Value) - (Val(DGV.Rows(e.RowIndex).Cells(4).Value * (Val(DGV.Rows(e.RowIndex).Cells(5).Value)) / 100))
                DGV.CurrentCell = DGV(5, DGV.CurrentCell.RowIndex)
                Call HitungBarang()
                Call HitungHarga()
                TXTTERBILANG.Text = Terbilang(Val(LBLTOTAL.Text)) & "Rupiah"
            Catch ex As Exception
                MsgBox("harus angka !")
                SendKeys.Send("{up}")
            End Try
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        DGV.Columns.Clear()
        Call buatkolom()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If ComboBox1.Text = "" Or LBLJUMLAHBARANG.Text = "" Or LBLTOTAL.Text = "" Or TXTDIBAYAR.Text = "" Or LBLKEMBALI.Text = "" Then
            MsgBox("Transaksi belum lengkap")
            Exit Sub
        Else
            Call koneksi()
            Dim simpan1 As String = "insert into tblpenjualan values ('" & LBLFAKTUR.Text & "','" & LBLTANGGAL.Text & "','" & LBLJUMLAHBARANG.Text & "','" & LBLTOTAL.Text & "','" & TXTDISKON.Text & "','" & LBLHARGADIKON.Text & "','" & TXTDIBAYAR.Text & "','" & LBLKEMBALI.Text & "','" & Microsoft.VisualBasic.Right(ComboBox1.Text, 4) & "','" & FRM_MAIN.Label1.Text & "')"
            cmd = New OdbcCommand(simpan1, conn)
            cmd.ExecuteNonQuery()
            'lakukan input data ke tabel jual berkali kali sebanyak barang yang dibeli
            For baris As Integer = 0 To DGV.RowCount - 2
                Call koneksi()
                Dim simpan2 As String = "insert into tbldetailjual values ('" & LBLFAKTUR.Text & "','" & DGV.Rows(baris).Cells(0).Value & "','" & DGV.Rows(baris).Cells(1).Value & "','" & DGV.Rows(baris).Cells(2).Value & "','" & DGV.Rows(baris).Cells(3).Value & "','" & DGV.Rows(baris).Cells(4).Value & "','" & DGV.Rows(baris).Cells(5).Value & "','" & DGV.Rows(baris).Cells(6).Value & "')"
                cmd = New OdbcCommand(simpan2, conn)
                cmd.ExecuteNonQuery()


                Call koneksi()
                cmd = New OdbcCommand("select * from tblbarang where kode_barang='" & DGV.Rows(baris).Cells(0).Value & "'", conn)
                dr = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    'lakukan pengurangan stok ketabel barang berkali kali sebanyak barang yang terjual
                    Call koneksi()
                    Dim kurangistok As String = "update tblbarang set stok='" & dr.Item("stok") - DGV.Rows(baris).Cells(3).Value & "' where kode_barang='" & DGV.Rows(baris).Cells(0).Value & "'"
                    cmd = New OdbcCommand(kurangistok, conn)
                    cmd.ExecuteNonQuery()
                End If
            Next
            '===========opsi cetak faktur dengan rumus di vb
            'Cetakan.CRV.SelectionFormula = "{TBLPENJUALAN.FAKTUR}='" & Label2.Text & "'"
            'Cetakan.CRV.Refresh()
            'Cetakan.CRV.ReportSource = "FAKTUR.RPT"
            'Cetakan.CRV.RefreshReport()
            'Cetakan.Show()
            'Cetakan.CRV.ReportSource = Nothing
            'Cetakan.CRV.ReportSource = "faktur.rpt"
            'Cetakan.CRV.RefreshReport()

            'myReport.Load("FAKTUR.RPT")
            'myReport.Refresh()
            'myReport.PrintOptions.PrinterName = "EPSON T13 T22E SERIES"
            'myReport.PrintToPrinter(1, False, 0, 0)
            '===========opsi cetak faktur dengan rumus di buat di crystalreport
            If MessageBox.Show("cetak Faktur...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Cetakan.Show()
                Cetakan.Crv.ReportSource = Nothing
                Cetakan.Crv.ReportSource = "REPORT/faktur.rpt"
                Cetakan.Crv.RefreshReport()

                'myReport.Load("REPORT/FAKTUR.RPT")
                'myReport.Refresh()
                'myReport.PrintOptions.PrinterName = "EPSON T13 T22E SERIES"
                'myReport.PrintToPrinter(1, False, 0, 0)
                '================================
            Else
                Call Bersihkan()
                Call FAKTUR()
            End If
            Call Bersihkan()
            Call FAKTUR()
        End If
    End Sub


    Private Sub DGV_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DGV.KeyPress
        On Error Resume Next
        If e.KeyChar = Chr(27) Then
            DGV.Rows.RemoveAt(DGV.CurrentCell.RowIndex)
            Call HitungBarang()
            Call HitungHarga()
        End If

        If e.KeyChar = Chr(13) Then
            TXTDIBAYAR.Focus()
        End If
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TXTDIBAYAR.KeyPress
        If e.KeyChar = Chr(13) Then
            If Val(TXTDIBAYAR.Text) < Val(LBLTOTAL.Text) Then
                MsgBox("Pembayaran kurang")
                Exit Sub
            ElseIf Val(TXTDIBAYAR.Text) = Val(LBLTOTAL.Text) Then
                LBLKEMBALI.Text = 0
                If MessageBox.Show("ADA DISKON..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                    TXTDISKON.Focus()
                Else
                    Button1.Focus()
                End If
            ElseIf Val(TXTDIBAYAR.Text) > Val(LBLTOTAL.Text) Then
                LBLKEMBALI.Text = Val(TXTDIBAYAR.Text) - Val(LBLTOTAL.Text)
                If MessageBox.Show("ADA DISKON..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                    TXTDISKON.Focus()
                Else
                    LBLHARGADIKON.Text = 0
                    TXTDISKON.Text = 0
                    LBLKEMBALI.Text = Val(TXTDIBAYAR.Text) - Val(LBLTOTAL.Text)
                    Button1.Focus()
                End If
            End If
        End If



    End Sub

    Private Sub ComboBox1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ComboBox1.MouseDoubleClick
        DGV.Focus()
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TXTDISKON.KeyPress
        If e.KeyChar = Chr(13) Then
            LBLHARGADIKON.Text = Val(LBLTOTAL.Text) - Val(LBLTOTAL.Text) * (Val(TXTDISKON.Text) / 100)
            LBLKEMBALI.Text = Val(TXTDIBAYAR.Text) - Val(LBLHARGADIKON.Text)
            TXTTERBILANG.Text = Terbilang(Val(LBLTOTAL.Text)) & " Rupiah"
            Button1.Focus()

        End If
    End Sub

    Private Sub DGV_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellContentClick

    End Sub

    Private Sub TXTDISKON_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TXTDISKON.TextChanged

    End Sub
End Class