﻿Imports System.Data.Odbc
Public Class LATIHAN
    Sub GRID()
        Call koneksi()
        da = New OdbcDataAdapter("SELECT * FROM penulis", conn)
        ds = New DataSet
        da.Fill(ds)
        DGV.DataSource = ds.Tables(0)
    End Sub

    Private Sub PEMBELIAN_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call GRID()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Call koneksi()
        cmd = New OdbcCommand("insert into penulis(nama) values('" & TextBox1.Text & "')", conn)
        If cmd.ExecuteNonQuery Then
            Call GRID()
        End If
    End Sub
End Class