<div class="container">
<fieldset><h3 align="center">Data Peserta Calon Yang sudah Verifikasi</h3></fieldset>
	<table id="example" class="table table-boredered display">
		<thead>
			<tr>
				<th>Nama Lengkap</th>
				<th>Jenis Kelamin</th>
				<th>Email</th>
				<th>Telepon</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				$sql = $db->query("SELECT * FROM member ");
				while ($r = $sql->fetch_array()) {
			echo "<tr>
				<td>$r[nama_lengkap]</td>
				<td>$r[jenis_kelamin]</td>
				<td>$r[email]</td>
				<td>$r[telepon]</td>
			</tr>";
				}
			 ?>
		</tbody>
	</table>
	<hr>
	<a href="index.php" class="btn btn-warning" id="kembali">Kembali</a>
</div>