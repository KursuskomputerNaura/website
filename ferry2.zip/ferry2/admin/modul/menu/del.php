<?php 
$db->query("delete from menuadmin where id='$_GET[id]'");
header('location:?page=menu');
?>