<?php 
akses();
$db->query("delete from faq where id_faq='$_GET[id]'");
header('location:?page=faq');
?>