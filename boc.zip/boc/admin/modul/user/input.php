<?php
$db->query("INSERT INTO user SET nama_lengkap='$_POST[nama_lengkap]',
								 username='$_POST[username]',
								 password='".md5($_POST[password])."',
								 email='$_POST[email]'");
header('location:?page=user');
?>