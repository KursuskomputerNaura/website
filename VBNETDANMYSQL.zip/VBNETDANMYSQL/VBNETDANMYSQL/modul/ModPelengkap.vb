﻿Module ModPelengkap
    'Deklarasi Global
    Public SQl As String
    Public Tabel As DataTable
    Public Proses As New ClsKoneksiDatabase
    Public Kode As New ClsPelengkap
    Public Pelengkap As New ClsPelengkap
    Public VarStr, VarStr1, VarStr2, VarStr3 As String
    Public Status, Posisi_Record As Boolean
    Public Diskon As Single
    Public No, Stock, Stock_Awal, Jml_Beli, Jml_Return, Jml_Jual, Sub_Total, No_Kartu As Integer
    Public Pengguna As String

    'Mengosongkan isi teks pada form keseluruhan
    Public Sub KosongkanIsiText(ByVal x As Form)
        For Each i As Control In x.Controls
            If TypeOf (i) Is TextBox Then
                i.Text = ""
                i.Focus()
            End If
        Next
    End Sub

    'Mengosongkan isi teks combobox pada form seluruh
    Public Sub KosongkanIsiCombo(ByVal x As Form)
        For Each i As Control In x.Controls
            If TypeOf (i) Is ComboBox Then
                i.Text = ""
            End If
        Next
    End Sub

    Public Function Enkripsi(ByVal teks As String) As String
        Dim Teks_Asli As String, Teks_Sandi As String, PanjangTeks As Long
        'Dim Pos As Long, EnkripsiKarakter, EnkripsiText
        Dim Pos As Long
        Dim EnkripsiKarakter, EnkripsiText As String
        Teks_Asli = " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890?!@#$%^&*()_+|;:,'.-`~"
        Teks_Sandi = "?!@#$%^&*()_+|;:,'.-`~1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
        For PanjangTeks = 1 To Len(teks)
            Pos = InStr(Teks_Asli, Mid(teks, PanjangTeks, 1))
            If Pos > 0 Then
                EnkripsiKarakter = Mid(Teks_Sandi, Pos, 1)
                ' EnkripsiText = 'EnkripsiText + EnkripsiKarakter
            Else
                'EnkripsiText = EnkripsiText + Mid(teks, PanjangTeks, 1)
            End If
        Next
        'Enkripsi = EnkripsiText
    End Function
End Module


