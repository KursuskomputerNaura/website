 <?php
        
        $page = isset($_GET['page']) ? $_GET['page']:'';
        $act = isset($_GET['act']) ? $_GET['act']:'';
        if ($page) {
            if (empty($act)) {
               include "modul/$page/index.php";
            }else{
                include "modul/$page/$act.php";
            }
        }else{
            include "modul/home.php";
        }
        ?> 