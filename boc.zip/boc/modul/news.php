
<?php 
  $sql = $db->query("SELECT * FROM artikel ");
  while ($r = $sql->fetch_array()) {
    $isi = strip_tags(substr($r['isi'], 0,250));
echo "<div class='content_services_A'>
<h3>$r[judul]</h3>
   <img src='gambar/$r[gambar]' alt='$r[judul]' width='200' height='150' />
       <p>$isi</p>
       <a href='?page=detail&id=$r[id_artikel]'>Selengkapnya</a>
</div>";
  }
?>
