<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i>Data Halaman</span>
                    </div>
                    <div class='mws-panel-toolbar '>
                        <div class='btn-toolbar'>
                            <div class='btn-group'>
                                <a href='?page=halaman&act=add' class='btn'><i class='icon-box-add'></i> Add Halaman</a>
                            </div>
                        </div>
                    </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Gambar</th>
                                    <th>Author</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $halaman = $db->query("select * from view_halaman");
                                while ($r = $halaman->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[judul]</td>
                                    <td><img src='../gambar/$r[gambar]' width='100'></td>
                                    <td>$r[username]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=halaman&act=edit&id=$r[id_halaman]'>Edit</a>
                                            <a href='?page=halaman&act=del&id=$r[id_halaman]'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>
                