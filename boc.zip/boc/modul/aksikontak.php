<?php 
	$db->query("INSERT INTO kontak SET nama_lengkap='$_POST[nama_lengkap]',
		                               email='$_POST[email]',
		                               telepon='$_POST[telepon]',
		                               pesan='$_POST[pesan]'");
	echo "<script>
           alert('Pesan berhasil dikirim');
           window.location='?page=kontak';
	</script>";
?>