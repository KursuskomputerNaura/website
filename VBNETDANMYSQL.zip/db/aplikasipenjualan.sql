-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 03, 2017 at 12:12 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `aplikasipenjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbarang`
--

CREATE TABLE IF NOT EXISTS `tblbarang` (
  `kode_barang` char(5) NOT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `satuan` varchar(30) DEFAULT NULL,
  `harga_beli` int(11) DEFAULT NULL,
  `harga_jual` int(11) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbarang`
--

INSERT INTO `tblbarang` (`kode_barang`, `nama_barang`, `satuan`, `harga_beli`, `harga_jual`, `stok`) VALUES
('B001', 'BERAS', 'LITER', 8000, 10000, 1494),
('B003', 'JAGUNG', 'KILO', 300, 400, 999),
('B002', 'GULA', 'KILO', 2000, 2000, 1499),
('nm,nm', 'mnmn', 'mnmn', 797, 997, 979),
('mnnmn', 'mnmnm', 'mmnm', 866, 8686, 868);

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE IF NOT EXISTS `tblcustomer` (
  `kode_customer` char(5) NOT NULL,
  `nama_customer` varchar(30) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `kontak` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`kode_customer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbldetailjual`
--

CREATE TABLE IF NOT EXISTS `tbldetailjual` (
  `faktur` char(10) DEFAULT NULL,
  `kode_barang` char(5) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `harga` decimal(8,0) DEFAULT NULL,
  `diskon_peritem` decimal(8,0) DEFAULT NULL,
  `jumlah` decimal(4,0) DEFAULT NULL,
  `harga_diskon_peritem` decimal(18,0) DEFAULT NULL,
  `subtotal` decimal(8,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldetailjual`
--

INSERT INTO `tbldetailjual` (`faktur`, `kode_barang`, `nama_barang`, `harga`, `diskon_peritem`, `jumlah`, `harga_diskon_peritem`, `subtotal`) VALUES
('1701020002', 'b001', 'BERAS', '10000', '1', '9999', '0', '10000'),
('1701020002', 'b002', 'GULA', '2000', '1', '2000', '0', '2000'),
('1701020003', 'b001', 'BERAS', '10000', '1', '9999', '0', '10000'),
('1701020004', 'b001', 'BERAS', '10000', '2', '9999', '0', '20000'),
('1701020004', 'b003', 'JAGUNG', '400', '1', '400', '0', '400'),
('1701020004', 'b004', '', '0', '0', '0', '0', '0'),
('1701030001', 'B001', 'BERAS', '10000', '1', '9999', '0', '10000'),
('1701030002', 'B001', 'BERAS', '10000', '1', '9999', '0', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `tblpenjualan`
--

CREATE TABLE IF NOT EXISTS `tblpenjualan` (
  `faktur` char(10) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `total_barang` decimal(4,0) DEFAULT NULL,
  `total_harga` decimal(8,0) DEFAULT NULL,
  `diskon` decimal(18,0) DEFAULT NULL,
  `harga_diskon` decimal(18,0) DEFAULT NULL,
  `dibayar` decimal(8,0) DEFAULT NULL,
  `kembali` decimal(8,0) DEFAULT NULL,
  `kode_customer` char(5) DEFAULT NULL,
  `kode_user` char(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpenjualan`
--

INSERT INTO `tblpenjualan` (`faktur`, `tanggal`, `total_barang`, `total_harga`, `diskon`, `harga_diskon`, `dibayar`, `kembali`, `kode_customer`, `kode_user`) VALUES
('1701020001', '2017-01-02', '1', '10000', '1', '9900', '20000', '10100', 'cash', 'Label'),
('1701020002', '2017-01-02', '2', '12000', '1', '11880', '15000', '3120', 'cash', 'Label'),
('1701020003', '2017-01-02', '1', '10000', '1', '9900', '20000', '10100', 'cash', 'Label'),
('1701020004', '2017-01-02', '3', '20400', '0', '0', '21000', '600', 'cash', 'Label'),
('1701030001', '2017-01-03', '1', '10000', '0', '0', '10000', '0', 'CASH', 'Label'),
('1701030002', '2017-01-03', '1', '10000', '1', '9900', '10000', '100', 'CASH', 'Label');

-- --------------------------------------------------------

--
-- Table structure for table `tblsupplier`
--

CREATE TABLE IF NOT EXISTS `tblsupplier` (
  `kode_supplier` char(5) NOT NULL,
  `nama_supplier` varchar(30) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `kontak` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`kode_supplier`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsupplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `kode_user` char(5) DEFAULT NULL,
  `nama_user` varchar(30) DEFAULT NULL,
  `pwd_user` varchar(30) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`kode_user`, `nama_user`, `pwd_user`, `status`, `photo`) VALUES
('U001', 'ADMIN', 'ADMIN', 'ADMIN', 'icon.png'),
('U002', 'USER', 'USER', 'USER', 'icon.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
