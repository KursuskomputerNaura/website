<?php

$id       = $_POST['id'];
$jumlah   = count($id);
$lulus  = $_POST['lulus'];
 if ($lulus<>"") {
   
    for ($i=1; $i<=$jumlah; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
//      setelah data dibaca, masukkan ke tabel memeber 
      $hasil = $db->query("UPDATE member SET lulus='".$lulus[$i]."' WHERE id_member='".$id[$i]."'");
    }

    
    if($hasil){
    // jika  Berhasil
          echo "<script>
            alert('Data berhasil di update');
            window.location='?page=member';
          </script>";
      }else{
        print_r($hasil);
         echo "<script>
            alert('Data Gagal di update');
            window.location='?page=member';
          </script>";
      }
    

 }
  

 
?>

 
