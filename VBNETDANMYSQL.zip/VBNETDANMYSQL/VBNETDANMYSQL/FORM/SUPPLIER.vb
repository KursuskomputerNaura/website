﻿'PAKE ACSSESS
'Imports System.Data.OleDb
'PAKE MYSQL
Imports System.Data.Odbc
'PAKE SQLSERVER
'Imports System.Data.SqlClient
Public Class SUPPLIER
    Sub grid()
        Call KONEKSI()
        da = New OdbcDataAdapter("SELECT * from tblSUPPLIER", conn)
        DS = New DataSet
        DA.Fill(DS)
        dgv.DataSource = DS.Tables(0)
    End Sub
    Sub KETEMU()
        TextBox2.Text = DR.Item(1)
        TextBox3.Text = DR.Item(2)
        TextBox4.Text = DR.Item(3)
        TextBox5.Text = DR.Item(4)
    End Sub
    Sub BERSIH()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub
    Private Sub SUPPLIER_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call grid()
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            Call KONEKSI()
            cmd = New OdbcCommand("SELECT * FROM TBLSUPPLIER WHERE KODE_SUPPLIER='" & TextBox1.Text & "'", conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If DR.HasRows Then
                Call KETEMU()
            Else
                TextBox2.Focus()
            End If
        End If
    End Sub



    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox4.Focus()
        End If
    End Sub

    Private Sub TextBox4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox5.Focus()
        End If
    End Sub

    Private Sub TextBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox5.KeyPress
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub



    Private Sub DGV_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV.CellMouseClick
        On Error Resume Next
        TextBox1.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        TextBox2.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        TextBox3.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        TextBox4.Text = DGV.Rows(e.RowIndex).Cells(3).Value
        TextBox5.Text = DGV.Rows(e.RowIndex).Cells(4).Value
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged
        Call KONEKSI()
        cmd = New OdbcCommand("SELECT * FROM TBLSUPPLIER WHERE KODE_SUPPLIER LIKE '%" & TextBox6.Text & "%'", conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Call KONEKSI()
            da = New OdbcDataAdapter("SELECT * FROM TBLSUPPLIER WHERE KODE_SUPPLIER LIKE '%" & TextBox6.Text & "%'", conn)
            DS = New DataSet
            DA.Fill(DS)
            DGV.DataSource = DS.Tables(0)
            DGV.ReadOnly = True
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Lengkapi Datanya !")
            Exit Sub

        End If

        Call KONEKSI()
        cmd = New OdbcCommand("SELECT * FROM TBLSUPPLIER WHERE KODE_SUPPLIER='" & TextBox1.Text & "'", conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If Not DR.HasRows Then
            Call KONEKSI()
            Dim TAMBAH As String = "INSERT INTO TBLSUPPLIER VALUES('" & TextBox1.Text & _
                                                                 "','" & TextBox2.Text & _
                                                                 "','" & TextBox3.Text & _
                                                                 "','" & TextBox4.Text & _
                                                                 "','" & TextBox5.Text & _
                                                                 "')"
            cmd = New OdbcCommand(TAMBAH, conn)
            CMD.ExecuteNonQuery()
            Call grid()
            Call BERSIH()
        Else
            Call KONEKSI()
            Dim UBAH As String = "UPDATE TBLSUPPLIER SET NAMA_SUPPLIER='" & TextBox2.Text & _
                                                    "',ALAMAT='" & TextBox3.Text & _
                                                    "',TELEPON='" & TextBox4.Text & _
                                                    "',CONTACT_PERSON='" & TextBox5.Text & _
                                                    "' WHERE KODE_SUPPLIER='" & TextBox1.Text & "'"
            cmd = New OdbcCommand(UBAH, conn)
            CMD.ExecuteNonQuery()
            Call grid()
            Call BERSIH()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("KETIK KODE YANG AKAN DIHAPUS PADA TEXTBOX1")
            Exit Sub
        Else
            If MessageBox.Show("APAKAH ANDA INGIN MENGHAPUS DATA INI ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call KONEKSI()
                cmd = New OdbcCommand("DELETE FROM TBLSUPPLIER WHERE KODE_SUPPLIER='" & TextBox1.Text & "'", conn)
                CMD.ExecuteNonQuery()
                Call grid()
                Call BERSIH()
            Else
                Call BERSIH()
            End If
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call BERSIH()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub
End Class