<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Data kontak</span>
                    </div>
                    <div class="mws-panel-toolbar top clearfix">
                            
                        </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Email</th>
                                    <th>Telepon</th>
                                    <th>Pesan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $kontak = $db->query("select * from kontak");
                                while ($r = $kontak->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[nama_lengkap]</td>
                                    <td>$r[email]</td>
                                    <td>$r[telepon]</td>
                                    <td>$r[pesan]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=kontak&act=edit&id=$r[id_kontak]'>Balas</a>
                                            <a href='?page=kontak&act=del&id=$r[id_kontak]'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>

                