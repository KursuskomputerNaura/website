<?php
akses(); 
$db->query("UPDATE menuadmin SET parent_id='$_POST[parent_id]',
								 title='$_POST[title]',
								 url='$_POST[url]',
								 icon='$_POST[icon]',
								 menu_order='$_POST[menu_order]'
								 WHERE id='$_POST[id]'");
header('location:?page=menu');
?>