<?php
akses(); 
$db->query("delete from artikel where id_artikel='$_GET[id]'");
header('location:?page=artikel');
?>