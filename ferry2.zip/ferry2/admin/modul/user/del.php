<?php 
akses();
$db->query("delete from user where id_user='$_GET[id]'");
header('location:?page=user');
?>