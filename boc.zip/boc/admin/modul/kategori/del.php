<?php 
akses();
$db->query("delete from kategori where id_kategori='$_GET[id]'");
header('location:?page=kategori');
?>