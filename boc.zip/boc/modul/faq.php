<div class="content">
<h3>pertanyaan umum :</h3>
	<ol>
	    <li>Apasih yang dimaksud dengan banten Rally wisata ?
	    <ul>
	        <li>Banten Rally wisata adalah sebuah acara yang ditujukan bagi orang orang yang ingin berwisata sekaligus melakukan kegiatan olahraga</li>
	    </ul>
	    </li>
	    <li>Bagai mana cara mengikuti acara ini ?
	    <ul>
	        <li>Anda bisa mendaftarkan diri di website pendaftaran untuk event ini atau <a href="">klik disini</a></li>
	    </ul>
	    </li>
	    <li>Apa yang harus saya persiapkan ?
	    <ul>
	        <li>Siapkan mental dan kesehatan lalu mengikuti proses pendaftaran</li>
	    </ul>
	    </li>
	    <li>Apakah acara ini mendapat sponsor ?
	    <ul>
	        <li>ya acara ini didukung oleh beberapa sponsor</li>
	    </ul>
	    </li>
	</ol>

	<h3>Jika ada yang ingin ditanyakan kepada team kami anda bisa mengajukan pertanyaan lewat form di bawah ini</h3>
	<form action="?page=aksifaq" method="POST" role="form">
      <fieldset>Form Tanya Jawab
      <table width="100%">
        <tr>
          <td>Nama</td>
          <td><input type="text" name="nama_lengkap"></td>
        </tr>
        <tr>
          <td>Email</td>
          <td><input type="email" name="email"></td>
        </tr>
        <tr>
          <td>Pesan</td>
          <td><textarea name="pesan" rows="5" cols="30"></textarea></td>
        </tr>
        <tr>
          <td></td>
          <td><input type="submit" value="kirim"><td>
        </tr>
      </table>
      </form>
      </fieldset>
      <hr><h3>Pertanyaan yang sudah terjawab</h3>
      <table border="1" width="100%">
      	<thead>
      		<tr>
      			<th>No</th>
      			<th>Nama</th>
      			<th>Pertanyaan</th>
      			<th>Lihat</th>
      		</tr>
      	</thead>
      	<tbody>
      		<?php 
          $no=1;
            $sql = $db->query("select * from faq");
            while ($r = $sql->fetch_array()) {
        echo "<tr>
            <td>$no</td>
            <td>$r[nama_lengkap]</td>
            <td>$r[pesan]</td>
            <td><a href='?page=detailfaq&id=$r[id_faq]'>baca</a></td>
          </tr>";
          $no++;
            }
          ?>
      	</tbody>
      </table><hr>

</div>