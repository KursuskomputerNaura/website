<?php
$sql = $db->query("select * from member where id_member='$_POST[no_daftar]' AND nama_lengkap='$_POST[nama_lengkap]'");
if ($sql->num_rows>0) {
	$gambar = $_FILES['gambar']['name'];
	move_uploaded_file($_FILES['gambar']['tmp_name'], "gambar/$gambar");
 	$konfirmasi = $db->query("UPDATE member SET konfirmasi='Y',
 	                                 bukti_bayar='$gambar'
 	                                 WHERE id_member='$_POST[no_daftar]'");
 	echo "<script>
           alert('Pesan Berhasil dikirim');
           window.location='?page=konfirmasi';
	</script>";
 }else{
echo "<script>
           alert('Anda Belum Terdaftar');
           window.location='?page=konfirmasi';
	</script>";
 } 

?>