<?php 
date_default_timezone_set('asia/jakarta');
$db = new mysqli('localhost','root','','imi-event');
?>