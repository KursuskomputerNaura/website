<?php
akses();
$db->query("UPDATE user SET nama_lengkap='$_POST[nama_lengkap]',
							email='$_POST[username]',
							telepon='$_POST[telepon]',
							pesan='$_POST[pesan]'
							WHERE id_user='$_POST[id]'");
$to      = $_POST['email'];
$subject = "Dari Banten Rally Wisata";
$body 	 = $_POST['pesan'];
$headers = "From: admin@localhost \r\n";
$headers.="Reply-to: admin@localhost \r\n";
$headers.='MIME-Version: 1.0'."\r\n";
$headers.='Content-type: text/html; charset=iso-8859-1'."\r\n";
mail($to, $subject, $body,$headers);

header('location:?page=user');
?>