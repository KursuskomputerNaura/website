<?php 
	function akses()
	{
		if (empty($_SESSION['namauser']) AND empty($_SESSION['password'])) {
			header('location:index.php');
		}
	}
?>