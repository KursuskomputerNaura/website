<?php 
akses(); 
$edit = $db->query("select * from member where id_member='$_GET[id]'");
$r = $edit->fetch_array();
?>

<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span>Form Edit member</span>
                    </div>
                    <div class='mws-panel-body no-padding'>
                        <form class='mws-form' action='?page=member&act=update' method="post">
                        <input type='hidden' name="id" value="<?php echo $r['id_member']; ?>">
                            <div class='mws-form-inline'>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Nama Lengkap</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="nama_lengkap"  class='mws-textinput' value="<?php echo $r['nama_lengkap']; ?>">
                                    </div>
                                </div>
                                
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Tempat Lahir</label>
                                    <div class='mws-form-item'>
                                        <input type='text' name="tempat_lahir" class='mws-textinput' value="<?php echo $r['tempat_lahir']; ?>">
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Tanggal Lahir</label>
                                    <div class='mws-form-item'>
                                        <input type='date' name="tanggal_lahir" class='mws-textinput' value="<?php echo $r['tanggal_lahir']; ?>">
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Agama</label>
                                    <div class='mws-form-item'>
                                        <select name="agama" class="form-control">
                                            <option value="<?php echo $r['agama']; ?>"><?php echo $r['agama']; ?></option>
                                            <option value="Islam">Islam</option>
                                            <option value="Khatolik">Khatolik</option>
                                            <option value="Protestan">Protestan</option>
                                            <option value="Hindu">Hindu</option>
                                            <option value="Budha">Budha</option>
                                        </select>
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Jenis Kelamin</label>
                                    <div class='mws-form-item'>
                                        <select name="jenis_kelamin" class="form-control">
                                            <option value="Laki-Laki" <?php if($r['jenis_kelamin']=='Laki-laki'){echo "selected";} ?>>Laki-Laki</option>
                                            <option value="Perempuan" <?php if($r['jenis_kelamin']=='Perempuan'){echo "selected";} ?>>Perempuan</option>
                                        </select>
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Email</label>
                                    <div class='mws-form-item'>
                                        <input type='email' name="email" class='mws-textinput' value="<?php echo $r['email']; ?>">
                                    </div>
                                </div>

                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Password</label>
                                    <div class='mws-form-item'>
                                        <input type='password' name="password" class='mws-textinput' value="<?php echo $r['password']; ?>">
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Telepon</label>
                                    <div class='mws-form-item'>
                                        <input type='number' name="telepon" class='mws-textinput' value="<?php echo $r['telepon']; ?>">
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Aktif</label>
                                    <div class='mws-form-item'>
                                        <select name="aktif" class="form-control">
                                            <option value="Y" <?php if($r['aktif']=='Y'){echo "selected";} ?>>Aktif</option>
                                            <option value="N" <?php if($r['aktif']=='N'){echo "selected";} ?>>Tidak Aktif</option>
                                        </select>
                                    </div>
                                </div>
                                <div class='mws-form-row'>
                                    <label class='mws-form-label'>Lulus</label>
                                    <div class='mws-form-item'>
                                        <select name="lulus" class="form-control">
                                            <option value="Y" <?php if($r['lulus']=='Y'){echo "selected";} ?>>Y</option>
                                            <option value="N" <?php if($r['lulus']=='N'){echo "selected";} ?>>N</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class='mws-form-row'>
<label class='mws-form-label'>Bukti Pembayaran</label>
  <div class='mws-form-item'>
<img src="../gambar/<?php echo $r['bukti_bayar']; ?>" alt="">
</div>
</div>
                            <div class='mws-button-row'>
                                <input type='submit' value='Submit' class='mws-button green'>
                                 <a href='?page=member' class='mws-button orange'>Kembali</a>
                            </div>
                        </form>
                    </div>      
                </div>
                            