<div class='mws-panel grid_8'>
                    <div class='mws-panel-header'>
                        <span><i class='icon-table'></i> Data Menu</span>
                    </div>
                    <div class="mws-panel-toolbar top clearfix">
                            <ul>
                                <li><a href="?page=menu&act=add" class="mws-ic-16 ic-add">Add Data</a></li>
                            </ul>
                        </div>
                    <div class='mws-panel-body no-padding'>
                    <div class="table-responsive">
                        <table  class='mws-datatable-fn mws-table'>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Menu Induk</th>
                                    <th>Title</th>
                                    <th>Url</th>
                                    <th>Menu Order</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
                               $no=1; 
                                $menu = $db->query("select * from menuadmin");
                                while ($r = $menu->fetch_array()) {
                                    echo " 
                                    <tr>
                                    <td>$no</td>
                                    <td>$r[parent_id]</td>
                                    <td>$r[title]</td>
                                    <td>$r[url]</td>
                                    <td>$r[menu_order]</td>
                                    <td>
                                        <span class='btn-group'>
                                            <a href='?page=menu&act=edit&id=$r[id]'>Edit</a>
                                            <a href='?page=menu&act=del&id=$r[id]'>Delete</a>
                                        </span>
                                    </td>
                                </tr>";
                                $no++;
                                }
                               ?>
                                
                            </tbody>
                        </table>
                        </div>
                    </div>      
                </div>

                