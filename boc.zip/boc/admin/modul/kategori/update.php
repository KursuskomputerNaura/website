<?php 
akses();
$db->query("INSERT INTO kategori SET kategori='$_POST[kategori]' where id_kategori='$_POST[id]'");
header('location:?page=kategori');
?>