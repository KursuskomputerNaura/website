<?php 
akses();
$db->query("delete from halaman where id_halaman='$_GET[id]'");
header('location:?page=halaman');
?>