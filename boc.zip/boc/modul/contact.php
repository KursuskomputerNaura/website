<div class="content-kiri">
    <div id="alamat"><label>Sekretariat Panitia :</label><br>
    Balaraja Otomotif Sport club (BOC)<br>
    Jalan Balaraja Serang Km. 25 Kecamatan Balaraja<br>
    Kabupaten Tangerang Banten 15610
    </div>

      
    <div id="phone"><label>Contact</label><br>
      Anas Nasrudin (otem) | 0812 9888 7192<br>
      Email | Otem_inside92@yahoo.com<hr>

      Tedy Agustianesa | 0822 9929 1187<br>
      Email | tedy_agustianesa@yahoo.com<hr>
      
    </div>

    
   
   <!--  <div id="follow">
      <label>Social</label><br>
        <a href="#"><img src="img/social-media/facebook-flat.png" title="Facebook" width="40" height="40"/></a>
        <a href="#"><img src="img/social-media/twitter-flat.png" title="Twitter" width="40" height="40"/></a></div> --></div>
        
    

  <div class="content_kanan"><label>Location</label>
  <div id="map">
     <div id="map_box">
       <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3966.4622326132962!2d106.4509077147691!3d-6.202591895509792!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sJalan+Balaraja+Serang+Km.+25+Kecamatan+Balaraja!5e0!3m2!1sid!2sid!4v1480993213105" width="590" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
     </div></div></div>