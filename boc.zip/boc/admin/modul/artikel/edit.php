<?php 
akses();
$edit = $db->query("select * from artikel where id_artikel='$_GET[id]'");
$r = $edit->fetch_array();
?>
<div class="mws-panel grid_8">
                    <div class="mws-panel-header">
                        <span>Inline Form</span>
                    </div>
                    <div class="mws-panel-body no-padding">
                        <form class="mws-form" action="?page=artikel&act=update" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $r['id_artikel']; ?>">
                            <div class="mws-form-inline">
                                <div class="mws-form-row">
                                    <label class="mws-form-label">Judul</label>
                                    <div class="mws-form-item">
                                        <input type="text" class='mws-textinput' name="judul" value="<?php echo $r['judul']; ?>">
                                    </div>
                                </div>
                                <div class="mws-form-row">
                                    <label class="mws-form-label">Kategori</label>
                                    <div class="mws-form-item">
                                        <select class='small' name="id_kategori">
                                            <option>Pilih Menu</option>
                                            <?php 
                                                $sql = $db->query("select * from kategori");
                                                while ($s = $sql->fetch_array()) {
                                                   echo "<option value='$s[id_kategori]'"; if($s['id_kategori']==$r['id_kategori']){echo "selected";} echo">$s[kategori]</option>";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mws-form-row">
                                    <label class="mws-form-label">Isi</label>
                                    <div class="mws-form-item">
                                        <textarea rows="" cols="" class="large" id="elrte" name="isi"><?php echo $r['isi']; ?></textarea>
                                    </div>
                                </div>
                                
                               <div class="mws-form-row">
                                    <label class="mws-form-label">Gambar</label>
                                    <div class="mws-form-item">
                                        <img src="../gambar/<?php echo $r['gambar']; ?>">
                                        <input type="file" class="small" name="gambar">
                                    </div>
                                </div>
                            </div>
                            <div class="mws-button-row">
                                <input type="submit" value="Submit" class="mws-btn btn-danger">
                                <input type="reset" value="Reset" class="mws-btn ">
                            </div>
                        </form>
                    </div>      
                </div>



                