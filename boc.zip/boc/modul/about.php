<?php 
  $sql = $db->query("SELECT * FROM halaman where id_halaman=2");
  while ($r = $sql->fetch_array()) {
echo "<div class='content'>
    <h3>$r[judul]</h3>
  <img src='gambar/$r[gambar]' alt='$r[judul]$r[judul]' width='350' align='left' hspace='5'>
  <p>$r[isi]</p>
</div>";
  }
?>
